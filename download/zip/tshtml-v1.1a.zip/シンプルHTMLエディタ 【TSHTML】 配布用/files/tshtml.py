import tkinter as tk
from tkinter import filedialog, messagebox
import webbrowser
import tempfile
import os
import re

class HTMLEditor:
    def __init__(self, root):
        self.root = root
        self.root.title("シンプル HTMLエディタ TSHTML v1.0a")
        self.root.geometry("800x600")

        # メインの画面エリア
        main_frame = tk.Frame(self.root)
        main_frame.pack(expand=True, fill="both", padx=5, pady=5)

        # テキストを入力するエリア（スクロール付き、フォントはMS P明朝）
        self.text_area = tk.Text(main_frame, wrap="word", undo=True, font=("MS P明朝", 12))
        self.text_area.pack(side=tk.LEFT, expand=True, fill="both")
        
        # スクロールバー
        scrollbar = tk.Scrollbar(main_frame, command=self.text_area.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.text_area.config(yscrollcommand=scrollbar.set)

        # タグの色（青色）を設定して、文字を入力するたびに色を付ける
        self.text_area.tag_configure("tag", foreground="blue")
        self.text_area.bind("<KeyRelease>", self.highlight_syntax)

        # メニューバーを作成
        self.menu_bar = tk.Menu(self.root)
        self.root.config(menu=self.menu_bar)

        # ファイルメニュー
        self.file_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="ファイル", menu=self.file_menu)
        self.file_menu.add_command(label="開く...", command=self.open_file)
        self.file_menu.add_command(label="上書き保存", command=self.save_file)
        self.file_menu.add_separator()
        self.file_menu.add_command(label="終了", command=self.root.quit)

        # 便利機能メニュー
        self.tools_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="機能", menu=self.tools_menu)
        self.tools_menu.add_command(label="HTMLの枠組みを挿入", command=self.insert_template)
        self.tools_menu.add_command(label="ブラウザでプレビュー", command=self.preview_html)

        # ヘルプメニュー（新規追加）
        self.help_menu = tk.Menu(self.menu_bar, tearoff=0)
        self.menu_bar.add_cascade(label="ヘルプ", menu=self.help_menu)
        self.help_menu.add_command(label="使い方・補助", command=self.show_help)
        self.help_menu.add_command(label="バージョン情報", command=self.show_about)

        # 現在開いているファイルのパス
        self.file_path = None

    def insert_template(self):
        # HTMLの基本枠組みを自動で入力する
        template = """<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>タイトル</title>
</head>
<body>
    <h1>これは見出しのH1タグです。H2、H3、H4などもあります。</h1>
    <p>これは文章を入力するPタグです。</p>
    <li><p>liタグで箇条書きができます。</p></li>
</body>
</html>
"""
        self.text_area.insert("1.0", template)
        self.highlight_syntax()

    def preview_html(self):
        # 現在書いている内容を一時的に保存して、ブラウザで表示する
        content = self.text_area.get("1.0", tk.END)
        try:
            with tempfile.NamedTemporaryFile("w", delete=False, suffix=".html", encoding="utf-8") as f:
                f.write(content)
                temp_name = f.name
            webbrowser.open("file://" + os.path.abspath(temp_name))
        except Exception as e:
            messagebox.showerror("エラー", f"プレビューを表示できませんでした:\n{e}")

    def show_help(self):
        # 使い方やよく使うタグの補助情報を表示する
        help_text = (
            "【使い方・補助ガイド】\n\n"
            "1. 基本的な流れ:\n"
            "   [機能]メニューから「HTMLの枠組みを挿入」を選ぶと、最初から書きやすい状態になります。\n\n"
            "2. プレビュー方法:\n"
            "   [機能]メニューの「ブラウザでプレビュー」を選ぶと、実際の見栄えを確認できます。\n\n"
            "3. よく使うHTMLタグの例:\n"
            "   - <h1>見出し</h1> : 大きな見出しを作ります。\n"
            "   - <p>文章</p> : 段落（文章）を作ります。\n"
            "   - <a href=\"URL\">リンク文字</a> : 別のページへ移動するリンクを作ります。\n"
            "   - <br> : 改行をします。"
        )
        messagebox.showinfo("ヘルプ・使い方補助", help_text)

    def show_about(self):
        # バージョン情報を表示する
        about_text = "シンプル HTMLエディタ TSHTML\nバージョン: 1.0a\n\nPythonの標準機能だけで作られた、やさしいHTMLエディタです。"
        messagebox.showinfo("バージョン情報", about_text)

    def highlight_syntax(self, event=None):
        # HTMLタグ（< から > まで）を青色にする処理
        self.text_area.tag_remove("tag", "1.0", tk.END)
        text = self.text_area.get("1.0", tk.END)
        
        for match in re.finditer(r'<[^>]+>', text):
            start_idx = f"1.0 + {match.start()} chars"
            end_idx = f"1.0 + {match.end()} chars"
            self.text_area.tag_add("tag", start_idx, end_idx)

    def open_file(self):
        file_path = filedialog.askopenfilename(
            filetypes=[("HTMLファイル", "*.html"), ("すべてのファイル", "*.*")]
        )
        if file_path:
            try:
                with open(file_path, "r", encoding="utf-8") as file:
                    content = file.read()
                self.text_area.delete("1.0", tk.END)
                self.text_area.insert("1.0", content)
                self.file_path = file_path
                self.root.title(f"シンプル HTMLエディタ - {file_path}")
                self.highlight_syntax()
            except Exception as e:
                messagebox.showerror("エラー", f"ファイルを開けませんでした:\n{e}")

    def save_file(self):
        if self.file_path:
            try:
                content = self.text_area.get("1.0", tk.END)
                with open(self.file_path, "w", encoding="utf-8") as file:
                    file.write(content)
                messagebox.showinfo("保存", "ファイルを保存しました！")
            except Exception as e:
                messagebox.showerror("エラー", f"ファイルを保存できませんでした:\n{e}")
        else:
            file_path = filedialog.asksaveasfilename(
                defaultextension=".html",
                filetypes=[("HTMLファイル", "*.html"), ("すべてのファイル", "*.*")]
            )
            if file_path:
                try:
                    content = self.text_area.get("1.0", tk.END)
                    with open(file_path, "w", encoding="utf-8") as file:
                        file.write(content)
                    self.file_path = file_path
                    self.root.title(f"シンプル HTMLエディタ - {file_path}")
                    messagebox.showinfo("保存", "ファイルを保存しました！")
                except Exception as e:
                    messagebox.showerror("エラー", f"ファイルを保存できませんでした:\n{e}")

if __name__ == "__main__":
    root = tk.Tk()
    app = HTMLEditor(root)
    root.mainloop()