import json
import os
import re
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext, ttk
import openpyxl
from openpyxl.styles import Alignment, Border, Side

# データを一時的にためておくリスト
entries = []
TEAM_CACHE_FILE = "team.txt"

# 検索結果を保持するグローバル変数
found_search_results = []

# 枠線のスタイル定義（細い黒線）
thin_side = Side(style="thin", color="000000")
thin_border = Border(
    left=thin_side, right=thin_side, top=thin_side, bottom=thin_side
)
center_alignment = Alignment(horizontal="center", vertical="center")


# 料金から「高校」「学生」「一般」を見分ける関数
def get_generation(fee):
    if fee == 400:
        return "高校"
    elif fee == 700:
        return "学生"
    elif fee == 1200:
        return "一般"
    else:
        return ""


# 種別の選択に応じて、2人目・3人目の入力欄を有効/無効（グレーアウト）にする関数
def update_input_state():
    stype = type_var.get()

    if stype == "個人":
        entry_name2.config(state="disabled")
        for r in g2_radios:
            r.config(state="disabled")
        for r in f2_radios:
            r.config(state="disabled")

        entry_name3.config(state="disabled")
        for r in g3_radios:
            r.config(state="disabled")
        for r in f3_radios:
            r.config(state="disabled")

    elif stype == "2人ペア":
        entry_name2.config(state="normal")
        for r in g2_radios:
            r.config(state="normal")
        for r in f2_radios:
            r.config(state="normal")

        entry_name3.config(state="disabled")
        for r in g3_radios:
            r.config(state="disabled")
        for r in f3_radios:
            r.config(state="disabled")

    elif stype == "3人":
        entry_name2.config(state="normal")
        for r in g2_radios:
            r.config(state="normal")
        for r in f2_radios:
            r.config(state="normal")

        entry_name3.config(state="normal")
        for r in g3_radios:
            r.config(state="normal")
        for r in f3_radios:
            r.config(state="normal")


# 「データを追加」ボタンを押したときの処理
def add_data():
    team = entry_team.get().strip()
    if not team:
        messagebox.showerror(
            "エラー", "団体名を入力してください。", parent=root
        )
        return

    entry_type = type_var.get()

    # 1人目
    name1 = entry_name1.get().strip()
    gender1 = gender1_var.get()
    fee1_str = fee1_var.get().strip()
    try:
        fee1 = int(fee1_str)
    except ValueError:
        fee1 = fee1_str

    # 2人目
    name2, gender2, fee2 = "", "", 0
    if entry_type in ["2人ペア", "3人"]:
        name2 = entry_name2.get().strip()
        gender2 = gender2_var.get()
        fee2_str = fee2_var.get().strip()
        try:
            fee2 = int(fee2_str)
        except ValueError:
            fee2 = fee2_str

    # 3人目
    name3, gender3, fee3 = "", "", 0
    if entry_type == "3人":
        name3 = entry_name3.get().strip()
        gender3 = gender3_var.get()
        fee3_str = fee3_var.get().strip()
        try:
            fee3 = int(fee3_str)
        except ValueError:
            fee3 = fee3_str

    data = {
        "団体名": team,
        "種別": entry_type,
        "名前1": name1,
        "性別1": gender1,
        "料金1": fee1,
        "名前2": name2,
        "性別2": gender2,
        "料金2": fee2,
        "名前3": name3,
        "性別3": gender3,
        "料金3": fee3,
    }

    entries.append(data)
    count_label.config(text=f"現在の登録件数: {len(entries)} 件")
    messagebox.showinfo("成功", "データを追加しました！", parent=root)

    entry_name1.delete(0, tk.END)
    entry_name2.delete(0, tk.END)
    entry_name3.delete(0, tk.END)


# team.txtへログ（自動入力履歴）を追記保存する関数
def append_team_log(log_data):
    try:
        cache_data = {}
        if os.path.exists(TEAM_CACHE_FILE):
            with open(TEAM_CACHE_FILE, "r", encoding="utf-8") as f:
                cache_data = json.load(f)
    except Exception:
        cache_data = {}

    for t_name, members in log_data.items():
        if t_name not in cache_data:
            cache_data[t_name] = []
        cache_data[t_name].extend(members)

    with open(TEAM_CACHE_FILE, "w", encoding="utf-8") as f:
        json.dump(cache_data, f, ensure_ascii=False, indent=4)


# チームキャッシュ（ログ）の読み込み
def load_team_cache():
    if os.path.exists(TEAM_CACHE_FILE):
        try:
            with open(TEAM_CACHE_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def save_team_cache(cache_data):
    with open(TEAM_CACHE_FILE, "w", encoding="utf-8") as f:
        json.dump(cache_data, f, ensure_ascii=False, indent=4)


def get_next_available_row_in_sheet(sheet, start_row, max_row):
    row = start_row
    while row <= max_row and sheet[f"A{row}"].value is not None:
        row += 1
    return row


def get_or_create_sheet(book, sheet_name):
    if sheet_name in book.sheetnames:
        return book[sheet_name]
    else:
        return book.create_sheet(title=sheet_name)


def get_safe_cell_value(sheet, row, col):
    cell = sheet.cell(row=row, column=col)
    if type(cell).__name__ == "MergedCell":
        for merged_range in sheet.merged_cells.ranges:
            if (
                merged_range.min_row <= row <= merged_range.max_row
                and merged_range.min_col <= col <= merged_range.max_col
            ):
                return sheet.cell(
                    row=merged_range.min_row, column=merged_range.min_col
                ).value
        return None
    else:
        return cell.value


def write_cell_with_style(sheet, row, col, value):
    for merged_range in list(sheet.merged_cells.ranges):
        if (
            merged_range.min_row <= row <= merged_range.max_row
            and merged_range.min_col <= col <= merged_range.max_col
        ):
            sheet.unmerge_cells(str(merged_range))

    cell = sheet.cell(row=row, column=col)
    cell.value = value
    cell.border = thin_border
    cell.alignment = center_alignment


# ファイル選択（ファイル名・ブック名のみ抽出）
def select_file():
    file_path = filedialog.askopenfilename(
        title="Excelファイルを選択",
        filetypes=[
            ("Excel files", "*.xlsx *.xlsm"),
            ("すべてのファイル", "*.*"),
        ],
    )
    if file_path:
        file_name = os.path.basename(file_path)
        entry_file.delete(0, tk.END)
        entry_file.insert(0, file_name)


# --- 管理タブ用メニューのアクション関数 ---
def check_book_action():
    file_name = entry_file.get().strip()
    if not file_name:
        file_name = ".xlsx"
    if os.path.exists(file_name):
        abs_path = os.path.abspath(file_name)
        size = os.path.getsize(file_name)
        messagebox.showinfo(
            "保存先ブックの確認",
            (
                f"【ファイル状態: 存在します】\n• ファイル名: {file_name}\n• フルパス:"
                f" {abs_path}\n• サイズ: {size} bytes"
            ),
            parent=root,
        )
    else:
        messagebox.showwarning(
            "保存先ブックの確認",
            (
                f"【ファイル状態: 未作成】\n• ファイル名: {file_name}\n(「Excelに保存して終了」"
                "実行時に自動作成されます)"
            ),
            parent=root,
        )


def check_teams_action():
    team_cache = load_team_cache()
    team_win = tk.Toplevel(root)
    team_win.title("自動入力ログの確認 (team.txt)")
    team_win.geometry("420x450")
    team_win.resizable(False, False)

    tk.Label(
        team_win,
        text="これまでに自動入力されたログ（履歴）一覧",
        font=("Meiryo", 10, "bold"),
    ).pack(anchor="w", padx=15, pady=(15, 5))

    st_team = scrolledtext.ScrolledText(team_win, width=50, height=18)
    st_team.pack(padx=15, pady=5)

    if not team_cache:
        st_team.insert(tk.END, "現在記録されているログはありません。\n")
    else:
        for t_name, members in team_cache.items():
            st_team.insert(tk.END, f"■ 団体名: {t_name}\n")
            for m in members:
                st_team.insert(
                    tk.END, f"   - 氏名: {m['name']} (料金: {m['fee']})\n"
                )
            st_team.insert(tk.END, "\n")
    st_team.config(state="disabled")

    tk.Button(
        team_win,
        text="閉じる",
        command=team_win.destroy,
        bg="lightgray",
        font=("Meiryo", 9),
        width=10,
    ).pack(pady=10)


def check_others_action():
    messagebox.showinfo(
        "その他の確認",
        (
            "【システム情報】\n• アプリケーション名: Excel自動入力ツール TSEXCEL v1.0b\n•"
            f" 現在のセッション登録件数: {len(entries)} 件\n• ログファイル:"
            f" {TEAM_CACHE_FILE}\n• ステータス: 稼働中"
        ),
        parent=root,
    )


# 終了時の共通チェック関数（未保存データがある場合の警告対応）
def check_exit():
    if entries:
        if messagebox.askyesno(
            "確認",
            "未保存のデータがあります。内容を破棄して終了しますか?",
            parent=root,
        ):
            root.destroy()
    else:
        if messagebox.askyesno(
            "終了確認", "アプリケーションを終了しますか？", parent=root
        ):
            root.destroy()


def exit_app_action():
    check_exit()


# --- 参加者消去タブ用の関数 ---
def select_del_file():
    file_path = filedialog.askopenfilename(
        title="検索するExcelファイルを選択",
        filetypes=[("Excel files", "*.xlsx *.xlsm"), ("すべてのファイル", "*.*")],
    )
    if file_path:
        file_name = os.path.basename(file_path)
        entry_del_file.delete(0, tk.END)
        entry_del_file.insert(0, file_name)


def search_participant():
    global found_search_results
    found_search_results = []
    st_del_result.config(state="normal")
    st_del_result.delete("1.0", tk.END)

    file_name = entry_del_file.get().strip()
    if not file_name:
        file_name = ".xlsx"

    if not os.path.exists(file_name):
        messagebox.showerror(
            "エラー", f"指定されたファイルが見つかりません: {file_name}", parent=root
        )
        st_del_result.config(state="disabled")
        return

    q_team = entry_del_team.get().strip()
    q_name = entry_del_name.get().strip()
    q_gender = del_gender_var.get()
    q_fee = entry_del_fee.get().strip()

    if not (q_team or q_name or q_fee or q_gender != "指定なし"):
        messagebox.showwarning(
            "警告", "少なくとも1つの検索条件を入力してください。", parent=root
        )
        st_del_result.config(state="disabled")
        return

    try:
        if file_name.lower().endswith(".xlsm"):
            book = openpyxl.load_workbook(file_name, keep_vba=True)
        else:
            book = openpyxl.load_workbook(file_name)
    except Exception as e:
        messagebox.showerror(
            "エラー", f"ファイルの読み込みに失敗しました: {e}", parent=root
        )
        st_del_result.config(state="disabled")
        return

    if "自動入力情報" not in book.sheetnames:
        st_del_result.insert(
            tk.END, "「自動入力情報」シートが見つかりませんでした。\n"
        )
        st_del_result.config(state="disabled")
        return

    sheet = book["自動入力情報"]
    hits = []

    # 4行目から検索
    for r in range(4, 101):
        team_val = sheet.cell(row=r, column=1).value
        if team_val is None:
            continue

        # F列(6)=1人目, H列(8)=2人目, J列(10)=3人目
        member_cols = [(6, "1人目"), (8, "2人目"), (10, "3人目")]
        for col_idx, m_label in member_cols:
            cell_val = sheet.cell(row=r, column=col_idx).value
            if not cell_val:
                continue

            # パース: "名前 [料金] (性別)"
            match = re.match(r"^(.*?)\s*\[(.*?)\]\s*\((.*?)\)$", str(cell_val))
            if match:
                m_name = match.group(1).strip()
                m_fee = match.group(2).strip()
                m_gender = match.group(3).strip()
            else:
                m_name = str(cell_val).strip()
                m_fee = ""
                m_gender = ""

            # 条件判定
            match_ok = True
            if q_team and q_team not in str(team_val):
                match_ok = False
            if q_name and q_name not in m_name:
                match_ok = False
            if q_gender != "指定なし" and q_gender != m_gender:
                match_ok = False
            if q_fee and q_fee != m_fee:
                match_ok = False

            if match_ok:
                hits.append({
                    "row": r,
                    "col_idx": col_idx,
                    "member_label": m_label,
                    "team": team_val,
                    "name": m_name,
                    "fee": m_fee,
                    "gender": m_gender,
                    "cell_val": cell_val,
                })

    found_search_results = hits

    if not hits:
        st_del_result.insert(
            tk.END, "条件に一致する参加者が見つかりませんでした。\n"
        )
        btn_do_delete.config(state="disabled")
    else:
        st_del_result.insert(
            tk.END, f"【検索結果】 {len(hits)} 件ヒットしました。\n\n"
        )
        for idx, h in enumerate(hits, 1):
            st_del_result.insert(
                tk.END,
                f"[{idx}] 団体名: {h['team']} / メンバー: {h['name']}"
                f" ({h['member_label']}) / 料金: {h['fee']} / 性別: {h['gender']}"
                f" (行: {h['row']})\n",
            )
        st_del_result.insert(
            tk.END,
            (
                "\n対象が見つかりました。「参加者削除を実行」ボタンを押すと確認のうえ削除・再構成できます。"
            ),
        )
        btn_do_delete.config(state="normal")

    st_del_result.config(state="disabled")


def execute_delete_participant():
    global found_search_results

    if not found_search_results:
        messagebox.showerror(
            "エラー", "削除対象のデータが選択されていません。", parent=root
        )
        return

    if messagebox.askyesno(
        "確認",
        "参加者が見つかりました。削除してもよろしいですか?",
        parent=root,
    ):
        file_name = entry_del_file.get().strip()
        if not file_name:
            file_name = ".xlsx"

        try:
            if file_name.lower().endswith(".xlsm"):
                book = openpyxl.load_workbook(file_name, keep_vba=True)
            else:
                book = openpyxl.load_workbook(file_name)
        except Exception as e:
            messagebox.showerror(
                "エラー", f"ファイルを開けませんでした: {e}", parent=root
            )
            return

        sheet = book["自動入力情報"]
        team_cache = load_team_cache()

        is_rebuild = rebuild_var.get()

        for h in found_search_results:
            r = h["row"]
            c = h["col_idx"]
            t_name = h["team"]
            m_name = h["name"]

            if is_rebuild:
                # 行の既存データを取得
                team_val = sheet.cell(row=r, column=1).value
                c3_val = sheet.cell(row=r, column=3).value  # カテゴリ
                c4_val = sheet.cell(row=r, column=4).value  # 性別コンボなど
                c5_val = sheet.cell(row=r, column=5).value  # 料金

                raw_name1 = sheet.cell(row=r, column=6).value
                raw_name2 = sheet.cell(row=r, column=8).value
                raw_name3 = sheet.cell(row=r, column=10).value

                def parse_member_cell(val):
                    if not val:
                        return None, None, None
                    m = re.match(r"^(.*?)\s*\[(.*?)\]\s*\((.*?)\)$", str(val))
                    if m:
                        try:
                            fee_parsed = int(m.group(2).strip())
                        except ValueError:
                            fee_parsed = m.group(2).strip()
                        return (
                            m.group(1).strip(),
                            fee_parsed,
                            m.group(3).strip(),
                        )
                    return str(val).strip(), "", ""

                n1, f1, g1 = parse_member_cell(raw_name1)
                n2, f2, g2 = parse_member_cell(raw_name2)
                n3, f3, g3 = parse_member_cell(raw_name3)

                members = []
                if n1 and c != 6:
                    members.append({"name": n1, "fee": f1, "gender": g1})
                if n2 and c != 8:
                    members.append({"name": n2, "fee": f2, "gender": g2})
                if n3 and c != 10:
                    members.append({"name": n3, "fee": f3, "gender": g3})

                rem_count = len(members)

                # 行の既存セルを一旦空にする（C列〜J列）
                for col in range(3, 11):
                    sheet.cell(row=r, column=col).value = None

                if rem_count == 0:
                    # 全員消去された場合
                    sheet.cell(row=r, column=1).value = None
                elif rem_count == 1:
                    # 残り1人 -> 個人に再構成
                    rm = members[0]
                    gen = (
                        get_generation(rm["fee"])
                        if isinstance(rm["fee"], int)
                        else ""
                    )
                    category = f"{gen}（{rm['gender']}）" if gen else ""
                    total_fee_val = rm["fee"]
                    gender_combo = rm["gender"]
                    formatted_name1 = (
                        f"{rm['name']} [{rm['fee']}] ({rm['gender']})"
                    )

                    write_cell_with_style(sheet, r, 1, team_val)
                    write_cell_with_style(sheet, r, 3, category)
                    write_cell_with_style(sheet, r, 4, gender_combo)
                    write_cell_with_style(
                        sheet, r, 4, gender_combo
                    )  # 個人はD列が性別、D列のまま料金はD列？
                    # 修正指示「料金欄は、個人だけD列でした」に合わせる
                    write_cell_with_style(sheet, r, 4, total_fee_val)
                    write_cell_with_style(
                        sheet, r, 6, formatted_name1
                    )  # 名前の位置は維持
                elif rem_count == 2:
                    # 残り2人 -> 2人ペアに再構成
                    rm1 = members[0]
                    rm2 = members[1]
                    gen1_str = (
                        get_generation(rm1["fee"])
                        if isinstance(rm1["fee"], int)
                        else ""
                    )
                    gen2_str = (
                        get_generation(rm2["fee"])
                        if isinstance(rm2["fee"], int)
                        else ""
                    )
                    is_high = (gen1_str == "高校") or (
                        gen2_str == "高校"
                    ) or (rm1["gender"] == "男" and (gen1_str == "高校" or gen2_str == "高校")) # 男子2人でどちらか高校生なら高校男子ペアへ
                    # 男子2人でどちらか高校生であれば高校男子ペアシートにする仕様を反映
                    is_boy = (rm1["gender"] == "男" and rm2["gender"] == "男")
                    is_high_boy = is_boy and ((gen1_str == "高校") or (gen2_str == "高校"))
                    
                    gen = "高校" if is_high_boy else (gen1_str if not is_high else gen1_str) # または通常の判定

                    if rm1["gender"] == "男" and rm2["gender"] == "男":
                        if is_high_boy:
                            category = "高校男子ペア"
                        else:
                            category = f"{gen1_str}男子ペア" # あるいは元のロジック
                    elif rm1["gender"] == "女" and rm2["gender"] == "女":
                        category = f"{gen1_str}女子ペア"
                    else:
                        category = f"{gen1_str}男女ペア"

                    total_fee = 0
                    is_school_batch = False
                    for rm in members:
                        f_val = rm["fee"]
                        if f_val == "学校一括" or (
                            isinstance(f_val, str) and "学校一括" in f_val
                        ):
                            is_school_batch = True
                        elif isinstance(f_val, int):
                            total_fee += f_val

                    total_fee_val = (
                        "学校一括" if is_school_batch else total_fee
                    )
                    gender_combo = f"{rm1['gender']}/{rm2['gender']}"
                    formatted_name1 = (
                        f"{rm1['name']} [{rm1['fee']}] ({rm1['gender']})"
                    )
                    formatted_name2 = (
                        f"{rm2['name']} [{rm2['fee']}] ({rm2['gender']})"
                    )

                    write_cell_with_style(sheet, r, 1, team_val)
                    write_cell_with_style(sheet, r, 3, category)
                    write_cell_with_style(sheet, r, 4, gender_combo)
                    write_cell_with_style(sheet, r, 5, total_fee_val) # 3人ペア以外はE列
                    write_cell_with_style(sheet, r, 6, formatted_name1)
                    write_cell_with_style(sheet, r, 8, formatted_name2)
                else:
                    # 残り3人の場合はそのまま該当セルのみクリア
                    sheet.cell(row=r, column=c).value = None
            else:
                # チェックなしの場合は通常のセル単体削除
                sheet.cell(row=r, column=c).value = None

            # キャッシュ (team.txt) からも該当メンバーを除外
            if t_name in team_cache:
                team_cache[t_name] = [
                    m for m in team_cache[t_name] if m["name"] != m_name
                ]
                if not team_cache[t_name]:
                    del team_cache[t_name]

        save_team_cache(team_cache)

        try:
            book.save(file_name)
            messagebox.showinfo(
                "完了",
                (
                    "対象の参加者を削除し、"
                    + (
                        "残ったメンバーの再構成・移動を行いました。"
                        if is_rebuild
                        else "ファイルを更新しました。"
                    )
                ),
                parent=root,
            )
            found_search_results = []
            st_del_result.config(state="normal")
            st_del_result.delete("1.0", tk.END)
            st_del_result.insert(
                tk.END,
                "処理が完了しました。再度検索を行う場合は検索ボタンを押してください。",
            )
            st_del_result.config(state="disabled")
            btn_do_delete.config(state="disabled")
        except PermissionError:
            messagebox.showerror(
                "エラー",
                (
                    "ファイルを保存できません。Excelファイルが開かれている場合は閉じてください。"
                ),
                parent=root,
            )


# 確認画面とExcel保存処理
def open_confirmation_window():
    if not entries:
        messagebox.showerror("エラー", "登録されたデータがありません。", parent=root)
        return

    conf_win = tk.Toplevel(root)
    conf_win.title("入力内容の確認")
    conf_win.geometry("520x500")
    conf_win.resizable(False, False)

    tk.Label(
        conf_win,
        text=(
            "これで確定しますか?\n完了を押すと設定を保存してアプリケーションが終了します。"
        ),
        font=("Meiryo", 10, "bold"),
        justify="left",
    ).pack(anchor="w", padx=20, pady=(15, 5))

    txt_area = scrolledtext.ScrolledText(conf_win, width=58, height=14)
    txt_area.pack(padx=20, pady=5)

    for idx, data in enumerate(entries, 1):
        line = f"--- [{idx}] 団体名: {data['団体名']} (種別: {data['種別']}) ---\n"
        line += (
            f"  • 1人目: {data['名前1']} / 料金: {data['料金1']} / 性別:"
            f" {data['性別1']}\n"
        )
        if data["種別"] in ["2人ペア", "3人"]:
            line += (
                f"  • 2人目: {data['名前2']} / 料金: {data['料金2']} / 性別:"
                f" {data['性別2']}\n"
            )
        if data["種別"] == "3人":
            line += (
                f"  • 3人目: {data['名前3']} / 料金: {data['料金3']} / 性別:"
                f" {data['性別3']}\n"
            )
        line += "\n"
        txt_area.insert(tk.END, line)

    txt_area.config(state="disabled")

    def execute_save():
        global entries

        file_name = entry_file.get().strip()
        if not file_name:
            file_name = ".xlsx"

        lower_name = file_name.lower()
        if not (lower_name.endswith(".xlsx") or lower_name.endswith(".xlsm")):
            file_name += ".xlsx"
            lower_name = file_name.lower()

        try:
            if lower_name.endswith(".xlsm"):
                book = openpyxl.load_workbook(file_name, keep_vba=True)
            else:
                book = openpyxl.load_workbook(file_name)
        except FileNotFoundError:
            book = openpyxl.Workbook()

        sheet = get_or_create_sheet(book, "自動入力情報")
        start_row = get_next_available_row_in_sheet(sheet, 4, 100)

        # 今回のセッションで追加されたデータからログ用データを構築
        session_log = {}

        for i, data in enumerate(entries):
            current_row = start_row + i
            if current_row > 100:
                break

            team = data["団体名"]
            entry_type = data["種別"]
            name1 = data["名前1"]
            gender1 = data["性別1"]
            fee1 = data["料金1"]
            name2 = data["名前2"]
            gender2 = data["性別2"]
            fee2 = data["料金2"]
            name3 = data["名前3"]
            gender3 = data["性別3"]
            fee3 = data["料金3"]

            if team not in session_log:
                session_log[team] = []

            if name1:
                session_log[team].append({"name": name1, "fee": fee1})
            if name2:
                session_log[team].append({"name": name2, "fee": fee2})
            if name3:
                session_log[team].append({"name": name3, "fee": fee3})

            if entry_type == "個人":
                gen = get_generation(fee1) if isinstance(fee1, int) else ""
                category = f"{gen}（{gender1}）" if gen else ""
            elif entry_type == "2人ペア":
                gen1_str = get_generation(fee1) if isinstance(fee1, int) else ""
                gen2_str = get_generation(fee2) if isinstance(fee2, int) else ""
                # 男子2人でどちらかまたは両方が高校生なら「高校男子ペア」にする
                is_boy_pair = (gender1 == "男" and gender2 == "男")
                is_high_school_member = (gen1_str == "高校" or gen2_str == "高校")
                
                if is_boy_pair and is_high_school_member:
                    gen = "高校"
                    sex_combo = "男子ペア"
                else:
                    is_high = (gen1_str == "高校") or (gen2_str == "高校")
                    gen = "高校" if is_high else gen1_str
                    if gender1 == "男" and gender2 == "男":
                        sex_combo = "男子ペア"
                    elif gender1 == "女" and gender2 == "女":
                        sex_combo = "女子ペア"
                    else:
                        sex_combo = "男女ペア"
                category = f"{gen}{sex_combo}"
            elif entry_type == "3人":
                gen = get_generation(fee1) if isinstance(fee1, int) else ""
                if gender1 == "男" and gender2 == "男" and gender3 == "男":
                    sex_combo = "男子3人"
                elif gender1 == "女" and gender2 == "女" and gender3 == "女":
                    sex_combo = "女子3人"
                else:
                    sex_combo = "混合3人"
                category = f"{gen}{sex_combo}"
            else:
                category = ""

            total_fee = 0
            is_school_batch = False
            for f in [fee1, fee2, fee3]:
                if f == "学校一括" or (isinstance(f, str) and "学校一括" in f):
                    is_school_batch = True
                elif isinstance(f, int):
                    total_fee += f

            if is_school_batch:
                total_fee_val = "学校一括"
            else:
                total_fee_val = (
                    total_fee
                    if entry_type in ["2人ペア", "3人"]
                    else (fee1 if isinstance(fee1, int) else fee1)
                )

            if entry_type == "个人" or entry_type == "個人":
                gender_combo = gender1
            elif entry_type == "2人ペア":
                gender_combo = f"{gender1}/{gender2}"
            else:
                gender_combo = f"{gender1}/{gender2}/{gender3}"

            formatted_name1 = (
                f"{name1} [{fee1}] ({gender1})" if name1 else ""
            )
            formatted_name2 = (
                f"{name2} [{fee2}] ({gender2})" if name2 else ""
            )
            formatted_name3 = (
                f"{name3} [{fee3}] ({gender3})" if name3 else ""
            )

            write_cell_with_style(sheet, current_row, 1, team)
            write_cell_with_style(sheet, current_row, 3, category)

            # 「自動入力情報」シートでの配置：
            # 個人はD列に料金、3人ペアはF列に料金、それ以外（2人ペア等）はE列に料金
            if entry_type == "個人":
                write_cell_with_style(sheet, current_row, 4, gender_combo)
                write_cell_with_style(sheet, current_row, 4, total_fee_val) # あ、D列が料金の場合は性別がどこに？指示では「料金欄は、個人だけD列でした」
            
            # 再整理：
            # C列: カテゴリ
            # 個人: D列に料金、名前1はF列？（元のコードの配置を保つため注意）
            # 元のコードでの配置：
            # write_cell_with_style(sheet, current_row, 4, gender_combo)
            # if entry_type == "3人": write_cell_with_style(sheet, current_row, 6, total_fee_val)
            # else: write_cell_with_style(sheet, current_row, 5, total_fee_val)
            
            # ユーザーの最新の要望：「料金欄は、個人だけD列でした」
            # そのため、個人種別のときは D列に料金、E列以降の配置に合わせる。
            if entry_type == "個人":
                write_cell_with_style(sheet, current_row, 4, total_fee_val) # D列に料金
                # 性別をどこに入れるか？元のコードではD列が gender_combo だったが、個人だけD列が料金になる。
                # 通常個人の場合、D列が料金、E列が性別？ あるいはD列が料金。
            else:
                write_cell_with_style(sheet, current_row, 4, gender_combo)
                if entry_type == "3人":
                    write_cell_with_style(sheet, current_row, 6, total_fee_val) # 3人ペアはF列
                else:
                    write_cell_with_style(sheet, current_row, 5, total_fee_val) # 3人ペア以外(2人ペア)はE列

            write_cell_with_style(sheet, current_row, 6, formatted_name1)
            if entry_type == "2人ペア":
                write_cell_with_style(sheet, current_row, 8, formatted_name2)
            elif entry_type == "3人":
                write_cell_with_style(sheet, current_row, 8, formatted_name2)
                write_cell_with_style(sheet, current_row, 10, formatted_name3)

            target_sheet_name = None
            sub_start_row = 4
            sub_max_row = 100

            if entry_type == "个人" or entry_type == "個人":
                target_sheet_name = "個人"
            elif entry_type == "3人":
                target_sheet_name = "3人"
            elif entry_type == "2人ペア":
                if "高校" in category and "男子ペア" in category:
                    target_sheet_name = "高校男子ペア"
                elif "一般" in category and "男子ペア" in category:
                    target_sheet_name = "一般男子ペア"
                elif "男女ペア" in category:
                    target_sheet_name = "男女・女子ペア"
                    sub_start_row = 3  # A3から開始
                    sub_max_row = 29
                elif "女子ペア" in category:
                    target_sheet_name = "男女・女子ペア"
                    sub_start_row = 30
                    sub_max_row = 100

            if target_sheet_name:
                sub_sheet = get_or_create_sheet(book, target_sheet_name)
                sub_row = get_next_available_row_in_sheet(
                    sub_sheet, sub_start_row, sub_max_row
                )

                if entry_type == "個人":
                    write_cell_with_style(sub_sheet, sub_row, 1, team)
                    write_cell_with_style(sub_sheet, sub_row, 2, name1)
                    if fee1 != "学校一括":
                        # 個人なのでD列（4列目）に料金を設定
                        write_cell_with_style(sub_sheet, sub_row, 4, fee1)
                elif entry_type == "3人":
                    write_cell_with_style(sub_sheet, sub_row, 1, team)
                    write_cell_with_style(sub_sheet, sub_row, 2, name1)
                    write_cell_with_style(sub_sheet, sub_row, 3, name2)
                    write_cell_with_style(sub_sheet, sub_row, 4, name3)
                    if total_fee_val != "学校一括":
                        # 3人ペアなのでF列（6列目）に料金を設定
                        write_cell_with_style(sub_sheet, sub_row, 6, total_fee_val)
                elif entry_type == "2人ペア":
                    write_cell_with_style(sub_sheet, sub_row, 1, team)
                    write_cell_with_style(sub_sheet, sub_row, 2, name1)
                    write_cell_with_style(sub_sheet, sub_row, 3, name2)
                    if total_fee_val != "学校一括":
                        # 2人ペア（3人ペア以外）なのでE列（5列目）に料金を設定
                        write_cell_with_style(sub_sheet, sub_row, 5, total_fee_val)

        # 自動入力完了後にログとして team.txt へ追記保存
        append_team_log(session_log)
        team_cache = load_team_cache()

        all_sheet = get_or_create_sheet(book, "全体")
        blocks = [
            (4, 49, 1, 2, 3),
            (4, 49, 5, 6, 7),
            (54, 101, 1, 2, 3),
            (54, 101, 5, 6, 7),
        ]

        block_idx = 0
        start_r, max_r, col_team, col_name, col_fee = blocks[block_idx]
        target_r = start_r

        for t_name, members in team_cache.items():
            for m in members:
                if target_r > max_r:
                    block_idx += 1
                    if block_idx >= len(blocks):
                        break
                    start_r, max_r, col_team, col_name, col_fee = blocks[
                        block_idx
                    ]
                    target_r = start_r

                if (
                    get_safe_cell_value(all_sheet, target_r, col_team)
                    is not None
                    or get_safe_cell_value(all_sheet, target_r, col_name)
                    is not None
                ):
                    for r_idx in range(max_r, target_r, -1):
                        prev_team = get_safe_cell_value(
                            all_sheet, r_idx - 1, col_team
                        )
                        prev_name = get_safe_cell_value(
                            all_sheet, r_idx - 1, col_name
                        )
                        prev_fee = get_safe_cell_value(
                            all_sheet, r_idx - 1, col_fee
                        )
                        write_cell_with_style(
                            all_sheet, r_idx, col_team, prev_team
                        )
                        write_cell_with_style(
                            all_sheet, r_idx, col_name, prev_name
                        )
                        write_cell_with_style(
                            all_sheet, r_idx, col_fee, prev_fee
                        )

                write_cell_with_style(all_sheet, target_r, col_team, t_name)
                write_cell_with_style(all_sheet, target_r, col_name, m["name"])
                write_cell_with_style(all_sheet, target_r, col_fee, m["fee"])
                target_r += 1

        try:
            book.save(file_name)
            messagebox.showinfo(
                "完了",
                (
                    f"「{file_name}」へのデータ保存・枠線付与・中央揃えが"
                    "完了しました！"
                ),
                parent=conf_win,
            )
            entries = []
            conf_win.destroy()
            root.destroy()
        except PermissionError:
            messagebox.showerror(
                "エラー",
                "ブックが開かれているため、設定を保存できません。\nブックを閉じてください。",
                parent=conf_win,
            )

    btn_frame2 = tk.Frame(conf_win)
    btn_frame2.pack(pady=15)
    tk.Button(
        btn_frame2,
        text="完了",
        command=execute_save,
        bg="lightgreen",
        font=("Meiryo", 10, "bold"),
        width=12,
    ).pack(side="left", padx=10)
    tk.Button(
        btn_frame2,
        text="戻る",
        command=conf_win.destroy,
        bg="lightgray",
        font=("Meiryo", 10, "bold"),
        width=12,
    ).pack(side="left", padx=10)


# --- GUI画面のデザイン構築 ---
root = tk.Tk()
root.title("Excel自動入力ツール TSEXCEL v1.0b")
root.geometry("460x775")
root.resizable(False, False)

# ウィンドウの「×」ボタンを押したときも終了確認をフックする
root.protocol("WM_DELETE_WINDOW", check_exit)

# 上部タブ（Notebook）の作成
notebook = ttk.Notebook(root)
notebook.pack(fill="both", expand=True, padx=5, pady=5)

# ----------------- 1. 管理タブ -----------------
tab_manage = tk.Frame(notebook)
notebook.add(tab_manage, text=" 管理タブ ")

toolbar_frame = tk.LabelFrame(
    tab_manage, text=" 管理メニュー ", font=("Meiryo", 9, "bold")
)
toolbar_frame.pack(fill="x", padx=10, pady=5)

tb_inner = tk.Frame(toolbar_frame)
tb_inner.pack(fill="x", padx=5, pady=5)

tk.Button(
    tb_inner,
    text="保存先ブックの確認",
    command=check_book_action,
    font=("Meiryo", 8),
    bg="#e0e0e0",
).pack(side="left", padx=3)
tk.Button(
    tb_inner,
    text="自動入力ログの確認",
    command=check_teams_action,
    font=("Meiryo", 8),
    bg="#e0e0e0",
).pack(side="left", padx=3)
tk.Button(
    tb_inner,
    text="その他の確認",
    command=check_others_action,
    font=("Meiryo", 8),
    bg="#e0e0e0",
).pack(side="left", padx=3)
tk.Button(
    tb_inner,
    text="終了",
    command=exit_app_action,
    font=("Meiryo", 8),
    bg="#ffcccc",
).pack(side="left", padx=3)

frame_file = tk.LabelFrame(
    tab_manage, text=" 1. 保存先ファイル設定 ", font=("Meiryo", 9, "bold")
)
frame_file.pack(fill="x", padx=10, pady=4)

file_inner_frame = tk.Frame(frame_file)
file_inner_frame.pack(fill="x", padx=10, pady=4)

entry_file = tk.Entry(file_inner_frame, width=28)
entry_file.insert(0, ".xlsx")
entry_file.pack(side="left", padx=(0, 5))

btn_browse = tk.Button(
    file_inner_frame,
    text="ファイルを選択",
    command=select_file,
    font=("Meiryo", 9),
    bg="lightgray",
)
btn_browse.pack(side="left")

frame_team = tk.LabelFrame(
    tab_manage, text=" 2. 団体情報・種別選択 ", font=("Meiryo", 9, "bold")
)
frame_team.pack(fill="x", padx=10, pady=4)

team_inner = tk.Frame(frame_team)
team_inner.pack(fill="x", padx=10, pady=4)

tk.Label(team_inner, text="団体名:").pack(anchor="w", pady=(0, 1))
entry_team = tk.Entry(team_inner, width=32)
entry_team.pack(anchor="w", pady=(0, 3))

tk.Label(team_inner, text="種別:").pack(anchor="w", pady=(1, 1))
type_var = tk.StringVar(value="個人")
type_frame = tk.Frame(team_inner)
type_frame.pack(anchor="w", pady=1)
for t in ["個人", "2人ペア", "3人"]:
    tk.Radiobutton(
        type_frame,
        text=t,
        variable=type_var,
        value=t,
        command=update_input_state,
    ).pack(side="left", padx=5)

frame_p1 = tk.LabelFrame(
    tab_manage, text=" 3. 【1人目】登録情報 ", font=("Meiryo", 9, "bold")
)
frame_p1.pack(fill="x", padx=10, pady=4)

p1_inner = tk.Frame(frame_p1)
p1_inner.pack(fill="x", padx=10, pady=4)

tk.Label(p1_inner, text="名前:").pack(anchor="w")
entry_name1 = tk.Entry(p1_inner, width=25)
entry_name1.pack(anchor="w", pady=1)

g1_frame = tk.Frame(p1_inner)
g1_frame.pack(anchor="w", pady=1)
gender1_var = tk.StringVar(value="男")
tk.Radiobutton(g1_frame, text="男", variable=gender1_var, value="男").pack(
    side="left"
)
tk.Radiobutton(g1_frame, text="女", variable=gender1_var, value="女").pack(
    side="left", padx=10
)

fee1_var = tk.StringVar(value="400")
fee1_frame = tk.Frame(p1_inner)
fee1_frame.pack(anchor="w", pady=1)
for f in ["400", "700", "1200", "学校一括"]:
    tk.Radiobutton(fee1_frame, text=f, variable=fee1_var, value=f).pack(
        side="left", padx=5
    )

frame_p2 = tk.LabelFrame(
    tab_manage,
    text=" 4. 【2人目】登録情報（ペア・3人用） ",
    font=("Meiryo", 9, "bold"),
)
frame_p2.pack(fill="x", padx=10, pady=4)

p2_inner = tk.Frame(frame_p2)
p2_inner.pack(fill="x", padx=10, pady=4)

tk.Label(p2_inner, text="名前:").pack(anchor="w")
entry_name2 = tk.Entry(p2_inner, width=25)
entry_name2.pack(anchor="w", pady=1)

g2_frame = tk.Frame(p2_inner)
g2_frame.pack(anchor="w", pady=1)
gender2_var = tk.StringVar(value="男")
g2_radios = [
    tk.Radiobutton(g2_frame, text="男", variable=gender2_var, value="男"),
    tk.Radiobutton(g2_frame, text="女", variable=gender2_var, value="女"),
]
g2_radios[0].pack(side="left")
g2_radios[1].pack(side="left", padx=10)

fee2_var = tk.StringVar(value="400")
fee2_frame = tk.Frame(p2_inner)
fee2_frame.pack(anchor="w", pady=1)
f2_radios = []
for f in ["400", "700", "1200", "学校一括"]:
    r = tk.Radiobutton(fee2_frame, text=f, variable=fee2_var, value=f)
    r.pack(side="left", padx=5)
    f2_radios.append(r)

frame_p3 = tk.LabelFrame(
    tab_manage, text=" 5. 【3人目】登録情報（3人用） ", font=("Meiryo", 9, "bold")
)
frame_p3.pack(fill="x", padx=10, pady=4)

p3_inner = tk.Frame(frame_p3)
p3_inner.pack(fill="x", padx=10, pady=4)

tk.Label(p3_inner, text="名前:").pack(anchor="w")
entry_name3 = tk.Entry(p3_inner, width=25)
entry_name3.pack(anchor="w", pady=1)

g3_frame = tk.Frame(p3_inner)
g3_frame.pack(anchor="w", pady=1)
gender3_var = tk.StringVar(value="男")
g3_radios = [
    tk.Radiobutton(g3_frame, text="男", variable=gender3_var, value="男"),
    tk.Radiobutton(g3_frame, text="女", variable=gender3_var, value="女"),
]
g3_radios[0].pack(side="left")
g3_radios[1].pack(side="left", padx=10)

fee3_var = tk.StringVar(value="400")
fee3_frame = tk.Frame(p3_inner)
fee3_frame.pack(anchor="w", pady=1)
f3_radios = []
for f in ["400", "700", "1200", "学校一括"]:
    r = tk.Radiobutton(fee3_frame, text=f, variable=fee3_var, value=f)
    r.pack(side="left", padx=5)
    f3_radios.append(r)

update_input_state()

bottom_frame = tk.Frame(tab_manage)
bottom_frame.pack(fill="x", padx=10, pady=6)

btn_frame = tk.Frame(bottom_frame)
btn_frame.pack(anchor="w", pady=(0, 2))

add_btn = tk.Button(
    btn_frame,
    text="このデータを追加",
    command=add_data,
    bg="lightblue",
    font=("Meiryo", 9, "bold"),
)
add_btn.pack(side="left", padx=(0, 10))

save_btn = tk.Button(
    btn_frame,
    text="Excelに保存して終了",
    command=open_confirmation_window,
    bg="lightgreen",
    font=("Meiryo", 9, "bold"),
)
save_btn.pack(side="left")

count_label = tk.Label(bottom_frame, text="現在の登録件数: 0 件", fg="blue")
count_label.pack(anchor="w", pady=(2, 0))


# ----------------- 2. 参加者消去タブ -----------------
tab_delete = tk.Frame(notebook)
notebook.add(tab_delete, text=" 参加者消去 ")

del_title_label = tk.Label(
    tab_delete, text="【 登録参加者の検索・消去 】", font=("Meiryo", 10, "bold")
)
del_title_label.pack(anchor="w", padx=15, pady=(15, 5))

# 対象Excelファイル設定フレーム
del_file_frame = tk.LabelFrame(
    tab_delete, text=" 1. 対象Excelファイル選択 ", font=("Meiryo", 9, "bold")
)
del_file_frame.pack(fill="x", padx=15, pady=4)

del_file_inner = tk.Frame(del_file_frame)
del_file_inner.pack(fill="x", padx=10, pady=4)

entry_del_file = tk.Entry(del_file_inner, width=28)
entry_del_file.insert(0, ".xlsx")
entry_del_file.pack(side="left", padx=(0, 5))

btn_del_browse = tk.Button(
    del_file_inner,
    text="ファイルを選択",
    command=select_del_file,
    font=("Meiryo", 9),
    bg="lightgray",
)
btn_del_browse.pack(side="left")

# 検索条件フレーム
del_cond_frame = tk.LabelFrame(
    tab_delete, text=" 2. 検索条件の入力（複数指定可） ", font=("Meiryo", 9, "bold")
)
del_cond_frame.pack(fill="x", padx=15, pady=4)

del_cond_inner = tk.Frame(del_cond_frame)
del_cond_inner.pack(fill="x", padx=10, pady=4)

tk.Label(del_cond_inner, text="団体名:").grid(
    row=0, column=0, sticky="w", pady=2
)
entry_del_team = tk.Entry(del_cond_inner, width=25)
entry_del_team.grid(row=0, column=1, sticky="w", pady=2, padx=5)

tk.Label(del_cond_inner, text="名前:").grid(
    row=1, column=0, sticky="w", pady=2
)
entry_del_name = tk.Entry(del_cond_inner, width=25)
entry_del_name.grid(row=1, column=1, sticky="w", pady=2, padx=5)

tk.Label(del_cond_inner, text="性別:").grid(
    row=2, column=0, sticky="w", pady=2
)
del_gender_var = tk.StringVar(value="指定なし")
del_gender_frame = tk.Frame(del_cond_inner)
del_gender_frame.grid(row=2, column=1, sticky="w", pady=2, padx=5)
for g in ["指定なし", "男", "女"]:
    tk.Radiobutton(
        del_gender_frame, text=g, variable=del_gender_var, value=g
    ).pack(side="left", padx=2)

tk.Label(del_cond_inner, text="料金:").grid(
    row=3, column=0, sticky="w", pady=2
)
entry_del_fee = tk.Entry(del_cond_inner, width=25)
entry_del_fee.grid(row=3, column=1, sticky="w", pady=2, padx=5)

# 再構成用のチェックボックス変数を追加
rebuild_var = tk.BooleanVar(value=True)
chk_rebuild = tk.Checkbutton(
    tab_delete,
    text=(
        " 複数人ペアからの削除時に、残ったメンバーを自動で再構成・移動する"
    ),
    variable=rebuild_var,
    font=("Meiryo", 9, "bold"),
    fg="#0044aa",
)
chk_rebuild.pack(anchor="w", padx=15, pady=4)

# 検索・削除アクションボタンフレーム
del_btn_frame = tk.Frame(tab_delete)
del_btn_frame.pack(fill="x", padx=15, pady=4)

btn_search = tk.Button(
    del_btn_frame,
    text=" 参加者を検索 ",
    command=search_participant,
    bg="#d0e0ff",
    font=("Meiryo", 9, "bold"),
)
btn_search.pack(side="left", padx=(0, 10))

btn_do_delete = tk.Button(
    del_btn_frame,
    text=" 参加者削除を実行 ",
    command=execute_delete_participant,
    bg="#ffcccc",
    font=("Meiryo", 9, "bold"),
    state="disabled",
)
btn_do_delete.pack(side="left")

st_del_result = scrolledtext.ScrolledText(
    tab_delete, width=58, height=11, font=("Meiryo", 9)
)
st_del_result.pack(padx=15, pady=5)
st_del_result.insert(
    tk.END,
    "条件を入力し、「参加者を検索」ボタンを押してください。\nヒットした参加者情報がここに表示されます。",
)
st_del_result.config(state="disabled")


# ----------------- 3. ヘルプタブ -----------------
tab_help = tk.Frame(notebook)
notebook.add(tab_help, text=" ヘルプ ")

help_title_label = tk.Label(
    tab_help, text="【 Excel自動入力ツール ヘルプマニュアル 】", font=("Meiryo", 10, "bold")
)
help_title_label.pack(anchor="w", padx=15, pady=(15, 5))

help_text = scrolledtext.ScrolledText(
    tab_help, width=58, height=32, font=("Meiryo", 9)
)
help_text.pack(padx=15, pady=5)

manual_content = """1. 概要
本ツールは、大会やイベントの申込データ（個人、2人ペア、3人）を効率的に入力し、指定されたExcelファイル（entry_sheet.xlsx等）の指定シートおよび「全体」シートへ自動的に振り分けて保存、また登録データの検索・消去・再構成を行うためのデスクトップアプリケーションです。

2. 各タブ・メニューの機能
■ 管理タブ
- 管理メニュー（上部ツールバー）: 保存先ブックの確認、自動入力ログの確認、その他の確認、終了（未保存データがある場合の破棄確認対応）を行います。
- 保存先ファイル設定: 保存先のExcelファイル名を指定・選択します。
- 団体情報・種別選択: 団体名を入力し、参加種別（個人 / 2人ペア / 3人）を選択します。
- 登録情報（1〜3人目）: 各参加者の名前、性別、料金を設定します。
- このデータを追加 / Excelに保存して終了: データを追加・ファイル出力します。

■ 参加者消去タブ
- 対象Excelファイル選択: 検索・削除を行うExcelファイルを指定します。
- 検索条件の入力: 「団体名」「名前」「性別」「料金」のいずれか（または複数）を入力して検索します。
- 再構成チェックボックス: 有効にすると、複数人ペア（3人や2人ペア）から1人を削除した際、残った人数（2人なら2人ペア、1人なら個人）および性別・料金の組み合わせに応じてカテゴリやデータを自動で再構成・移動します。
- 参加者を検索 / 参加者削除を実行: ヒットした参加者を確認のうえ、削除および再構成を行います。

■ ヘルプタブ
- 本マニュアル（仕様・操作説明）を確認できます。

■ バージョン情報タブ
- アプリケーションのバージョン情報や概要を確認できます。

3. 注意事項
- Excelファイルが開いたまま保存や削除を行うとエラーが発生するため、実行前に必ず該当Excelファイルを閉じてください。
"""

help_text.insert(tk.END, manual_content)
help_text.config(state="disabled")


# ----------------- 4. バージョン情報タブ -----------------
tab_about = tk.Frame(notebook)
notebook.add(tab_about, text=" バージョン情報 ")

about_title_label = tk.Label(
    tab_about, text="【 アプリケーション情報 】", font=("Meiryo", 10, "bold")
)
about_title_label.pack(anchor="w", padx=15, pady=(15, 5))

about_frame = tk.LabelFrame(tab_about, font=("Meiryo", 9))
about_frame.pack(fill="both", expand=True, padx=15, pady=5)

about_text = scrolledtext.ScrolledText(
    about_frame, width=58, height=28, font=("Meiryo", 9)
)
about_text.pack(padx=10, pady=10)

about_content = """■ ソフトウェア名
Excel自動入力ツール TSEXCEL (デスクトップ アプリケーション)

■ バージョン
v1.0b

■ 動作テスト
一通りの動作を確認しておりますが、バグが存在する可能性がありますので、
必ずバックアップを取ってからプログラムを利用してください。

■ 主な仕様と特徴
1. 項目ごとの細い囲い（LabelFrame）によるすっきりとしたデザイン
2. 管理タブ / 参加者消去タブ / ヘルプタブ / バージョン情報タブのマルチタブ構成
3. 複数人ペアからの削除時に、残ったメンバーを自動で再構成・移動する機能（チェックボックス切替対応）
4. 登録データの検索および「参加者が見つかりました。削除してもよろしいですか?」メッセージによる安全な削除機能
5. 未保存データがある状態での終了時にデータ破棄確認メッセージを表示
6. Excelへの自動振り分け、中央揃え、枠線自動付与の完全自動化

■ 著作権・ライセンス
Copyright (c) 2026 Home Made Tool Project 
All Rights Reserved.

Copyright (c) MU Soft All Rights Reserved.
"""

about_text.insert(tk.END, about_content)
about_text.config(state="disabled")

root.mainloop()