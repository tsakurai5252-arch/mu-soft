import os
import json
from datetime import datetime
import tkinter as tk
from tkinter import filedialog, messagebox, Scale, Toplevel, ttk
from PIL import Image, ImageDraw, ImageFont, ImageTk

# PDF読み込み用ライブラリ (PyMuPDF: pip install PyMuPDF)
try:
    import fitz
    PDF_SUPPORT = True
except ImportError:
    PDF_SUPPORT = False

class StampApp:
    def __init__(self, root):
        self.root = root
        self.root.title("デジタルスタンプ配置ソフト TSSTAMP v1.0c")
        self.root.geometry("560x730")
        self.root.resizable(False, False)

        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)

        self.target_file_paths = []
        self.is_processed = True
        
        # 一括処理用の一時保存データ
        self.batch_positions = {} 

        # 設定ファイルのパス
        self.settings_file = "Settings.dat"
        
        # 設定の初期値
        self.settings = {
            "high_quality_stamp": False,
            "custom_stamp_enabled": False,     # カスタムスタンプ有効/無効
            "auto_backup": True,
            "batch_process_mode": False,       # 一度で処理する（一括処理）ON/OFF
            "default_save_dir": "",            # デフォルトの保存先ディレクトリ
            
            # 通常データ用設定
            "scale_normal": 15,
            "font_size_main_normal": 30,
            "font_size_sub_normal": 26,

            # 高画質データ用設定
            "scale_hq": 15,
            "font_size_main_hq": 168,
            "font_size_sub_hq": 118,

            "default_save_mode": "new",
            "date_format": "YY.MM.DD",
            "time_format": "AM/PM"
        }
        self.load_settings()

        # --- タブコントロール（Notebook）の作成 ---
        self.notebook = ttk.Notebook(root)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=10)

        # 1. メイン処理タブ
        self.tab_main = tk.Frame(self.notebook)
        self.notebook.add(self.tab_main, text=" メイン処理 ")

        # 2. 設定タブ
        self.tab_settings = tk.Frame(self.notebook)
        self.notebook.add(self.tab_settings, text=" 設定 ")

        # 各タブの中身を構築
        self.create_main_tab_widgets()
        self.create_settings_tab_widgets()

        # --- メニューバーの作成 ---
        menubar = tk.Menu(root)

        menu_manage = tk.Menu(menubar, tearoff=0)
        menu_manage.add_command(label="ファイルを開く（追加）", command=self.select_files)
        menu_manage.add_command(label="ファイルリストをクリア", command=self.clear_files)
        menu_manage.add_separator()
        menu_manage.add_command(label="上書き保存モードに切替", command=lambda: self.save_mode.set("overwrite"))
        menu_manage.add_command(label="名前を付けて保存モードに切替", command=lambda: self.save_mode.set("new"))
        menu_manage.add_separator()
        menu_manage.add_command(label="終了", command=self.on_closing)
        menubar.add_cascade(label="管理", menu=menu_manage)

        menu_help = tk.Menu(menubar, tearoff=0)
        menu_help.add_command(label="ヘルプマニュアル", command=self.show_help)
        menu_help.add_command(label="バージョン情報", command=self.show_about)
        menubar.add_cascade(label="ヘルプ", menu=menu_help)

        root.config(menu=menubar)

        self.update_datetime()

    def load_settings(self):
        if os.path.exists(self.settings_file):
            try:
                with open(self.settings_file, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                    self.settings.update(loaded)
            except Exception as e:
                print(f"設定の読み込みに失敗しました: {e}")

    def save_settings(self):
        try:
            with open(self.settings_file, "w", encoding="utf-8") as f:
                json.dump(self.settings, f, ensure_ascii=False, indent=4)
            messagebox.showinfo("保存完了", "設定を Settings.dat に保存しました！")
        except Exception as e:
            messagebox.showerror("エラー", f"設定の保存に失敗しました:\n{e}")

    def get_current_scale(self):
        if self.settings.get("high_quality_stamp", False):
            return self.settings.get("scale_hq", 15)
        else:
            return self.settings.get("scale_normal", 10)

    def create_main_tab_widgets(self):
        # 1. ファイルリスト管理エリア
        frame_list = tk.LabelFrame(self.tab_main, text=" 選択したファイル一覧 (個別キャンセル・追加対応) ", font=("Meiryo", 10))
        frame_list.pack(pady=5, padx=10, fill="x")

        f_btn_box = tk.Frame(frame_list)
        f_btn_box.pack(pady=3)
        self.btn_select = tk.Button(f_btn_box, text="① ファイルを追加選択", command=self.select_files, font=("Meiryo", 9, "bold"), width=18, height=1)
        self.btn_select.pack(side=tk.LEFT, padx=2)
        
        self.btn_remove = tk.Button(f_btn_box, text="選択を削除(キャンセル)", command=self.remove_selected_file, font=("Meiryo", 9), width=18, height=1, fg="#d32f2f")
        self.btn_remove.pack(side=tk.LEFT, padx=2)

        self.btn_clear = tk.Button(f_btn_box, text="全クリア", command=self.clear_files, font=("Meiryo", 9), width=8, height=1)
        self.btn_clear.pack(side=tk.LEFT, padx=2)

        self.listbox = tk.Listbox(frame_list, height=4, font=("Meiryo", 9))
        self.listbox.pack(fill="x", padx=10, pady=5)

        # 2. 拡大率設定エリア
        frame_scale = tk.LabelFrame(self.tab_main, text=" スタンプの拡大率（幅に対する割合） ", font=("Meiryo", 10))
        frame_scale.pack(pady=5, padx=10, fill="x")

        f_scale_input = tk.Frame(frame_scale)
        f_scale_input.pack(pady=3, padx=10, anchor="w")
        tk.Label(f_scale_input, text="拡大率(%):", font=("Meiryo", 9)).pack(side=tk.LEFT)

        self.scale_var = tk.IntVar(value=self.get_current_scale())
        
        self.spin_scale = tk.Spinbox(
            f_scale_input, from_=1, to=300, textvariable=self.scale_var, width=6, font=("Meiryo", 10),
            command=self.on_spin_scale_changed
        )
        self.spin_scale.pack(side=tk.LEFT, padx=5)
        self.spin_scale.bind("<KeyRelease>", self.on_spin_scale_changed)

        self.slider = Scale(
            frame_scale, from_=1, to=300, orient=tk.HORIZONTAL, variable=self.scale_var, font=("Meiryo", 9)
        )
        self.slider.pack(fill="x", padx=10, pady=3)

        # 3. 日時表示エリア
        frame_date = tk.Frame(self.tab_main)
        frame_date.pack(pady=2)
        tk.Label(frame_date, text="日付 (自動):", font=("Meiryo", 10), width=16, anchor="w").pack(side=tk.LEFT)
        self.entry_date = tk.Entry(frame_date, font=("Meiryo", 11), width=18, state="disabled", disabledbackground="#e0e0e0", disabledforeground="#000000")
        self.entry_date.pack(side=tk.LEFT, padx=5)

        frame_time = tk.Frame(self.tab_main)
        frame_time.pack(pady=2)
        tk.Label(frame_time, text="時間 (自動):", font=("Meiryo", 10), width=16, anchor="w").pack(side=tk.LEFT)
        self.entry_time = tk.Entry(frame_time, font=("Meiryo", 11), width=18, state="disabled", disabledbackground="#e0e0e0", disabledforeground="#000000")
        self.entry_time.pack(side=tk.LEFT, padx=5)

        # 4. 保存方法の選択
        self.save_mode = tk.StringVar(value=self.settings.get("default_save_mode", "new"))
        frame_mode = tk.LabelFrame(self.tab_main, text=" 保存方法の選択 ", font=("Meiryo", 10))
        frame_mode.pack(pady=5, padx=10, fill="x")

        tk.Radiobutton(frame_mode, text="名前を付けて保存（個別に保存先を指定）", variable=self.save_mode, value="new", font=("Meiryo", 9)).pack(anchor="w", padx=10, pady=1)
        tk.Radiobutton(frame_mode, text="上書き保存（元のファイルを置き換える）", variable=self.save_mode, value="overwrite", font=("Meiryo", 9)).pack(anchor="w", padx=10, pady=1)

        # 5. 実行ボタン
        self.btn_execute = tk.Button(self.tab_main, text="② プレビューを開いてスタンプを配置する\n(1枚に複数配置可能 / Enterで次へ)", command=self.start_batch_process, font=("Meiryo", 10, "bold"), bg="#ff5252", fg="white", width=38, height=2)
        self.btn_execute.pack(pady=8)

    def on_spin_scale_changed(self, event=None):
        try:
            val = int(self.scale_var.get())
            if val < 1: self.scale_var.set(1)
            elif val > 300: self.scale_var.set(300)
        except ValueError:
            pass

    def create_settings_tab_widgets(self):
        container = tk.Frame(self.tab_settings)
        container.pack(fill="both", expand=True, padx=5, pady=5)

        # 1. カスタンプ ＆ スタンプデータ設定
        frame_stamp_cfg = tk.LabelFrame(container, text=" カスタムスタンプ ＆ スタンプ画質設定 ", font=("Meiryo", 9, "bold"))
        frame_stamp_cfg.pack(fill="x", padx=5, pady=3)

        self.custom_stamp_var = tk.BooleanVar(value=self.settings.get("custom_stamp_enabled", False))
        tk.Checkbutton(
            frame_stamp_cfg, 
            text="カスタムスタンプ機能を使用する (./stamps/ フォルダ)", 
            variable=self.custom_stamp_var, 
            font=("Meiryo", 9)
        ).pack(anchor="w", padx=10, pady=2)

        self.hq_var = tk.BooleanVar(value=self.settings.get("high_quality_stamp", False))
        tk.Checkbutton(
            frame_stamp_cfg, text="高画質スタンプデータを使用する (ok-high.png)", variable=self.hq_var, font=("Meiryo", 9),
            command=self.on_hq_toggled_ui
        ).pack(anchor="w", padx=10, pady=1)

        # 2. 一括処理＆保存先設定
        frame_batch_cfg = tk.LabelFrame(container, text=" 一括処理 ＆ 保存先フォルダ設定 ", font=("Meiryo", 9, "bold"))
        frame_batch_cfg.pack(fill="x", padx=5, pady=3)

        self.batch_mode_var = tk.BooleanVar(value=self.settings.get("batch_process_mode", False))
        tk.Checkbutton(
            frame_batch_cfg, 
            text="「一度で処理する」（全画像の場所を尋ねたのちに一括保存する）", 
            variable=self.batch_mode_var, 
            font=("Meiryo", 9)
        ).pack(anchor="w", padx=10, pady=2)

        f_dir = tk.Frame(frame_batch_cfg)
        f_dir.pack(fill="x", padx=10, pady=3)
        tk.Label(f_dir, text="デフォルト保存先:", font=("Meiryo", 9)).pack(side=tk.LEFT)
        self.entry_dir = tk.Entry(f_dir, font=("Meiryo", 9), width=28)
        self.entry_dir.insert(0, self.settings.get("default_save_dir", ""))
        self.entry_dir.pack(side=tk.LEFT, padx=5)
        
        def browse_dir():
            d = filedialog.askdirectory()
            if d:
                self.entry_dir.delete(0, tk.END)
                self.entry_dir.insert(0, d)

        tk.Button(f_dir, text="参照...", command=browse_dir, font=("Meiryo", 8), width=6).pack(side=tk.LEFT)

        # 3. バックアップ・日時フォーマット設定
        frame_detail = tk.LabelFrame(container, text=" バックアップ ＆ 日時フォーマット ", font=("Meiryo", 9, "bold"))
        frame_detail.pack(fill="x", padx=5, pady=3)

        self.backup_var = tk.BooleanVar(value=self.settings.get("auto_backup", True))
        tk.Checkbutton(frame_detail, text="処理時に自動バックアップを作成する (./buckup/)", variable=self.backup_var, font=("Meiryo", 9)).pack(anchor="w", padx=10, pady=1)

        f_dt = tk.Frame(frame_detail)
        f_dt.pack(fill="x", padx=10, pady=2)
        tk.Label(f_dt, text="日付形式:", font=("Meiryo", 9)).pack(side=tk.LEFT)
        self.date_format_var = tk.StringVar(value=self.settings.get("date_format", "YY.MM.DD"))
        date_options = ["YY.MM.DD", "MM.DD.YY", "DD.MM.YY", "YYYY.MM.DD", "YY/MM/DD", "YYYY/MM/DD"]
        ttk.Combobox(f_dt, textvariable=self.date_format_var, values=date_options, state="readonly", width=12, font=("Meiryo", 9)).pack(side=tk.LEFT, padx=5)

        tk.Label(f_dt, text="時刻:", font=("Meiryo", 9)).pack(side=tk.LEFT, padx=5)
        self.time_format_var = tk.StringVar(value=self.settings.get("time_format", "AM/PM"))
        tk.Radiobutton(f_dt, text="AM/PM", variable=self.time_format_var, value="AM/PM", font=("Meiryo", 9)).pack(side=tk.LEFT)
        tk.Radiobutton(f_dt, text="24H", variable=self.time_format_var, value="24H", font=("Meiryo", 9)).pack(side=tk.LEFT)

        btn_save_settings = tk.Button(
            container, text="設定を保存する", command=self.apply_and_save_settings, 
            font=("Meiryo", 9, "bold"), bg="#4caf50", fg="white", width=20, height=1
        )
        btn_save_settings.pack(pady=5)

    def on_hq_toggled_ui(self):
        self.settings["high_quality_stamp"] = self.hq_var.get()
        self.scale_var.set(self.get_current_scale())

    def apply_and_save_settings(self):
        self.settings["high_quality_stamp"] = self.hq_var.get()
        self.settings["custom_stamp_enabled"] = self.custom_stamp_var.get()
        self.settings["auto_backup"] = self.backup_var.get()
        self.settings["batch_process_mode"] = self.batch_mode_var.get()
        self.settings["default_save_dir"] = self.entry_dir.get().strip()
        self.settings["date_format"] = self.date_format_var.get()
        self.settings["time_format"] = self.time_format_var.get()
        
        self.scale_var.set(self.get_current_scale())
        self.save_settings()

    def get_formatted_datetime(self):
        now = datetime.now()
        d_fmt = self.settings.get("date_format", "YY.MM.DD")
        python_d_fmt = d_fmt.replace("YYYY", "%Y").replace("YY", "%y").replace("MM", "%m").replace("DD", "%d")
        date_str = now.strftime(python_d_fmt)

        t_fmt = self.settings.get("time_format", "AM/PM")
        if t_fmt == "24H":
            time_str = now.strftime("%H:%M:%S")
        else:
            time_str = now.strftime("AM %I:%M:%S" if now.hour < 12 else "PM %I:%M:%S")
        return date_str, time_str

    def update_datetime(self):
        date_str, time_str = self.get_formatted_datetime()
        for entry, val in [(self.entry_date, date_str), (self.entry_time, time_str)]:
            entry.config(state="normal")
            entry.delete(0, tk.END)
            entry.insert(0, val)
            entry.config(state="disabled")
        self.root.after(1000, self.update_datetime)

    def select_files(self):
        file_paths = filedialog.askopenfilenames(
            title="ファイルを選択（追加インポート可）",
            filetypes=[
                ("対応ファイル (画像/PDF)", "*.jpg *.jpeg *.png *.bmp *.pdf"),
                ("画像ファイル", "*.jpg *.jpeg *.png *.bmp"),
                ("PDFファイル", "*.pdf"),
                ("Excel・CSVファイル", "*.xlsx *.xls *.xlsm *.csv"),
                ("すべてのファイル", "*.*")
            ]
        )
        if file_paths:
            added_count = 0
            for path in file_paths:
                lower_path = path.lower()
                if lower_path.endswith(('.xlsx', '.xls', '.xlsm', '.csv', '.txt')):
                    messagebox.showwarning("対応外のファイル形式", f"「{os.path.basename(path)}」\nPDFファイルまたは画像ファイルに変換してください。")
                else:
                    if path not in self.target_file_paths:
                        self.target_file_paths.append(path)
                        added_count += 1

            if added_count > 0:
                self.refresh_listbox()
                self.is_processed = False

    def remove_selected_file(self):
        """リストで選択されているファイルを個別にキャンセル（削除）する"""
        selected_indices = self.listbox.curselection()
        if not selected_indices:
            messagebox.showwarning("選択エラー", "リストから削除（キャンセル）するファイルを選択してください。")
            return
        
        # 後ろのインデックスから順番に削除してズレを防ぐ
        for index in reversed(selected_indices):
            del self.target_file_paths[index]
        
        self.refresh_listbox()
        if not self.target_file_paths:
            self.is_processed = True

    def clear_files(self):
        self.target_file_paths = []
        self.refresh_listbox()
        self.is_processed = True

    def refresh_listbox(self):
        self.listbox.delete(0, tk.END)
        for path in self.target_file_paths:
            self.listbox.insert(tk.END, os.path.basename(path))

    def create_stamp_image(self):
        is_hq = self.settings.get("high_quality_stamp", False)
        use_custom = self.settings.get("custom_stamp_enabled", False)
        
        stamp_path = ""
        
        # 1. カスタムスタンプが有効な場合、./stamps/ フォルダ内を探索
        if use_custom:
            stamp_dir = "./stamps"
            if os.path.exists(stamp_dir):
                # フォルダ内の画像ファイルを検索
                valid_exts = ('.png', '.jpg', '.jpeg', '.bmp')
                custom_files = [os.path.join(stamp_dir, f) for f in os.listdir(stamp_dir) if f.lower().endswith(valid_exts)]
                if custom_files:
                    # 最初に見つかったカスタムスタンプ画像を採用
                    stamp_path = custom_files[0]

        # 2. カスタムが無効、または./stampsに画像がない場合はデフォルトスタンプを使用
        if not stamp_path:
            if is_hq:
                stamp_path = "./images/ok-high.png" if os.path.exists("./images/ok-high.png") else "ok-high.png"
            
            if not os.path.exists(stamp_path):
                stamp_path = "./images/ok.png" if os.path.exists("./images/ok.png") else "ok.png"

        stamp = Image.open(stamp_path).convert("RGBA")
        txt_layer = Image.new("RGBA", stamp.size, (255, 255, 255, 0))
        draw = ImageDraw.Draw(txt_layer)

        font_path = "./images/font.ttf" if os.path.exists("./images/font.ttf") else "font.ttf"
        fs_main = self.settings.get("font_size_main_hq", 168) if is_hq else self.settings.get("font_size_main_normal", 30)
        fs_sub = self.settings.get("font_size_sub_hq", 118) if is_hq else self.settings.get("font_size_sub_normal", 26)

        try:
            font_main = ImageFont.truetype(font_path, fs_main)
            font_sub = ImageFont.truetype(font_path, fs_sub)
        except IOError:
            font_main = ImageFont.load_default()
            font_sub = ImageFont.load_default()

        stamp_color = (210, 40, 40, 240)
        date_str, time_str = self.get_formatted_datetime()

        main_time = time_str[:-3] if (len(time_str) >= 3 and time_str[-3] == ":") else time_str
        sec_part = time_str[-3:] if (len(time_str) >= 3 and time_str[-3] == ":") else ""

        bbox_d = draw.textbbox((0, 0), date_str, font=font_main)
        bbox_t = draw.textbbox((0, 0), main_time, font=font_main)
        bbox_s = draw.textbbox((0, 0), sec_part, font=font_sub)

        w_date = bbox_d[2] - bbox_d[0]
        h_date = bbox_d[3] - bbox_d[1]
        w_time_main = bbox_t[2] - bbox_t[0]
        w_time_sec = bbox_s[2] - bbox_s[0]
        h_time = max(bbox_t[3] - bbox_t[1], bbox_s[3] - bbox_s[1])

        total_w = max(w_date, w_time_main + w_time_sec)
        total_h = h_date + h_time + 4

        start_x = (stamp.width - total_w) // 2
        start_y = (stamp.height - total_h) // 2

        draw.text((start_x + (total_w - w_date) // 2, start_y), date_str, fill=stamp_color, font=font_main)
        y_time = start_y + h_date + 4
        x_time_start = start_x + (total_w - (w_time_main + w_time_sec)) // 2
        draw.text((x_time_start, y_time), main_time, fill=stamp_color, font=font_main)
        draw.text((x_time_start + w_time_main, y_time + 2), sec_part, fill=stamp_color, font=font_sub)

        return Image.alpha_composite(stamp, txt_layer)

    def start_batch_process(self):
        if not self.target_file_paths:
            messagebox.showerror("エラー", "先にファイルを1つ以上選択してください。")
            return
        
        self.batch_positions = {}
        self.process_file_index(0)

    def process_file_index(self, index):
        if index >= len(self.target_file_paths):
            is_batch_mode = self.settings.get("batch_process_mode", False)
            default_dir = self.settings.get("default_save_dir", "").strip()

            if is_batch_mode and default_dir and os.path.exists(default_dir):
                now_str = datetime.now().strftime("%Y%m%d-%H%M%S")
                target_folder = os.path.join(default_dir, f"TS STAMP-{now_str}")
                os.makedirs(target_folder, exist_ok=True)

                for path, coords in self.batch_positions.items():
                    self.execute_save_action(path, coords, target_folder_override=target_folder)
                
                self.is_processed = True
                messagebox.showinfo("一括処理完了", f"すべての処理が完了しました！\n保存先: {target_folder}")
            else:
                for path, coords in self.batch_positions.items():
                    self.execute_save_action(path, coords, individual_interactive=True)
                
                self.is_processed = True
                messagebox.showinfo("完了", "すべてのファイルへのスタンプ合成が完了しました！")
            return

        file_path = self.target_file_paths[index]
        self.open_preview_window(file_path, index)

    def open_preview_window(self, file_path, index):
        preview_win = Toplevel(self.root)
        preview_win.title(f"[{index+1}/{len(self.target_file_paths)}] クリックでスタンプ配置 (複数可・Enterで次へ)")

        try:
            is_pdf = file_path.lower().endswith('.pdf')
            pil_img = None

            if is_pdf:
                if not PDF_SUPPORT:
                    messagebox.showerror("エラー", "PyMuPDFライブラリが必要です。")
                    preview_win.destroy()
                    return
                doc = fitz.open(file_path)
                page = doc[0]
                pix = page.get_pixmap(dpi=150)
                pil_img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            else:
                pil_img = Image.open(file_path)

            orig_w, orig_h = pil_img.size
            scale = min(800 / orig_w, 600 / orig_h, 1.0)
            
            disp_w, disp_h = int(orig_w * scale), int(orig_h * scale)
            disp_img = pil_img.resize((disp_w, disp_h), Image.Resampling.LANCZOS)
            base_tk_img = ImageTk.PhotoImage(disp_img)

            filename = os.path.basename(file_path)
            tk.Label(preview_win, text=f"({index+1}/{len(self.target_file_paths)}) {filename} - 左クリックで複数配置 / [Enter]キーで次へ進む", font=("Meiryo", 9), fg="red").pack(pady=3)

            canvas = tk.Canvas(preview_win, width=disp_w, height=disp_h, cursor="cross")
            canvas.pack()
            canvas.create_image(0, 0, anchor=tk.NW, image=base_tk_img)

            raw_stamp = self.create_stamp_image()
            scale_percent = self.scale_var.get()
            target_w_orig = int(orig_w * (scale_percent / 100.0))
            target_h_orig = int(target_w_orig * (raw_stamp.height / raw_stamp.width))
            
            disp_stamp = raw_stamp.resize((max(1, int(target_w_orig * scale)), max(1, int(target_h_orig * scale))), Image.Resampling.LANCZOS)
            stamp_tk_img = ImageTk.PhotoImage(disp_stamp)
            stamp_item = canvas.create_image(-100, -100, anchor=tk.CENTER, image=stamp_tk_img)

            current_coords = []

            def on_mouse_move(event):
                canvas.coords(stamp_item, event.x, event.y)

            canvas.bind("<Motion>", on_mouse_move)

            def on_canvas_click(event):
                orig_x = int(event.x / scale)
                orig_y = int(event.y / scale)
                current_coords.append((orig_x, orig_y))
                canvas.create_image(event.x, event.y, anchor=tk.CENTER, image=stamp_tk_img)

            canvas.bind("<Button-1>", on_canvas_click)

            def on_enter_pressed(event=None):
                self.batch_positions[file_path] = current_coords
                preview_win.destroy()
                self.process_file_index(index + 1)

            preview_win.bind("<Return>", on_enter_pressed)
            
            tk.Button(preview_win, text="この画像の配置を完了して次へ (Enter)", command=on_enter_pressed, font=("Meiryo", 9, "bold"), bg="#2196F3", fg="white").pack(pady=5)

            preview_win.base_tk_img = base_tk_img
            preview_win.stamp_tk_img = stamp_tk_img

        except Exception as e:
            messagebox.showerror("エラー", f"プレビュー表示エラー:\n{e}")

    def execute_save_action(self, file_path, coords_list, target_folder_override=None, individual_interactive=False):
        if not coords_list:
            return

        is_pdf = file_path.lower().endswith('.pdf')

        try:
            output_path = ""
            if target_folder_override:
                base_name, ext = os.path.splitext(os.path.basename(file_path))
                output_path = os.path.join(target_folder_override, f"{base_name}_stamped{ext}")
            elif self.save_mode.get() == "overwrite" and not individual_interactive:
                output_path = file_path
            else:
                base_dir = os.path.dirname(file_path)
                base_name, ext = os.path.splitext(os.path.basename(file_path))
                output_path = filedialog.asksaveasfilename(
                    initialdir=base_dir,
                    initialfile=f"{base_name}_stamped{ext}",
                    defaultextension=ext,
                    filetypes=[("対応ファイル", f"*{ext}"), ("すべてのファイル", "*.*")]
                )
                if not output_path:
                    return

            if is_pdf:
                doc = fitz.open(file_path)
                page = doc[0]
                pix = page.get_pixmap(dpi=150)
                base_img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples).convert("RGBA")
                
                stamped_stamp = self.create_stamp_image()
                scale_percent = self.scale_var.get()
                target_width = int(base_img.width * (scale_percent / 100.0))
                target_height = int(target_width * (stamped_stamp.height / stamped_stamp.width))
                stamped_stamp = stamped_stamp.resize((max(1, target_width), max(1, target_height)), Image.Resampling.LANCZOS)

                for (cx, cy) in coords_list:
                    base_img.paste(stamped_stamp, (cx - (target_width // 2), cy - (target_height // 2)), stamped_stamp)
                
                temp_img_path = "temp_stamped_page.png"
                base_img.convert("RGB").save(temp_img_path, "PNG", compress_level=0)
                
                img_doc = fitz.open(temp_img_path)
                pdf_bytes = img_doc.convert_to_pdf()
                img_doc.close()
                
                result_pdf = fitz.open("pdf", pdf_bytes)
                result_pdf.save(output_path)
                result_pdf.close()
                if os.path.exists(temp_img_path): os.remove(temp_img_path)
            else:
                base = Image.open(file_path).convert("RGBA")
                stamped_stamp = self.create_stamp_image()

                scale_percent = self.scale_var.get()
                target_width = int(base.width * (scale_percent / 100.0))
                target_height = int(target_width * (stamped_stamp.height / stamped_stamp.width))
                stamped_stamp = stamped_stamp.resize((max(1, target_width), max(1, target_height)), Image.Resampling.LANCZOS)

                for (cx, cy) in coords_list:
                    base.paste(stamped_stamp, (cx - (target_width // 2), cy - (target_height // 2)), stamped_stamp)

                if output_path.lower().endswith(('.jpg', '.jpeg')):
                    base.convert("RGB").save(output_path, quality=95, subsampling=0)
                else:
                    base.save(output_path, compress_level=0)

            if self.settings.get("auto_backup", True):
                backup_dir = "./buckup"
                os.makedirs(backup_dir, exist_ok=True)
                counter = 1
                while True:
                    backup_path = os.path.join(backup_dir, f"Copy{counter}.png")
                    if not os.path.exists(backup_path): break
                    counter += 1
                if is_pdf: base_img.convert("RGB").save(backup_path, "PNG")
                else: Image.open(output_path).convert("RGB").save(backup_path, "PNG")

        except Exception as e:
            messagebox.showerror("エラー", f"保存中にエラーが発生しました:\n{e}")

    def on_closing(self):
        if not self.is_processed and len(self.target_file_paths) > 0:
            if not messagebox.askyesno("警告", "未処理のファイルがあります。終了しますか？"): return
        else:
            if not messagebox.askyesno("確認", "アプリケーションを終了しますか？"): return
        self.root.destroy()

    def show_help(self):
        help_text = (
            "【 新機能の使い方 】\n\n"
            "■ ファイルの個別キャンセル（削除）\n"
            "   - リストから削除したいファイルを選択し、「選択を削除(キャンセル)」ボタンを押します。\n\n"
            "■ カスタムスタンプ機能\n"
            "   - 「設定」タブで「カスタムスタンプ機能を使用する」をONにし、 `./stamps/` フォルダに任意の画像（png等）を配置すると自動で適用されます（画像がない場合はデフォルトになります）。"
        )
        messagebox.showinfo("ヘルプマニュアル", help_text)

    def show_about(self):
        about_win = Toplevel(self.root)
        about_win.title("バージョン情報")
        about_win.geometry("370x220")
        about_win.resizable(False, False)
        tk.Label(about_win, text="デジタルスタンプ配置ソフト TSSTAMP", font=("Meiryo", 10, "bold")).pack(pady=15)
        tk.Label(about_win, text="Version 1.0c (2026.08.24)", font=("Meiryo", 9), fg="gray").pack(pady=5)
        tk.Label(about_win, text="Copyright (c) 2026 Home Made Tools Project", font=("Meiryo", 8)).pack(pady=5)
        tk.Button(about_win, text="閉じる", command=about_win.destroy, width=10).pack(pady=10)

if __name__ == "__main__":
    root = tk.Tk()
    app = StampApp(root)
    root.mainloop()