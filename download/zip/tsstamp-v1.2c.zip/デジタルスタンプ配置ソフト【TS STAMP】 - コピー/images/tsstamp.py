import os
import json
from datetime import datetime
import tkinter as tk
from tkinter import filedialog, messagebox, Scale, Toplevel, ttk
from PIL import Image, ImageDraw, ImageFont, ImageTk

class StampApp:
    def __init__(self, root):
        self.root = root
        self.root.title("デジタルスタンプ配置ソフト TSSTAMP v1.0a")
        self.root.geometry("540x640")
        self.root.resizable(False, False)

        self.root.protocol("WM_DELETE_WINDOW", self.on_closing)

        self.target_image_paths = []
        self.is_processed = True

        # 設定ファイルのパス
        self.settings_file = "Settings.dat"
        
        # 設定の初期値（通常・高画質で独立したデフォルト値）
        self.settings = {
            "high_quality_stamp": False,
            "auto_backup": True,
            
            # 通常データ用設定
            "scale_normal": 15,
            "font_size_main_normal": 30,
            "font_size_sub_normal": 26,

            # 高画質データ用設定
            "scale_hq": 15,
            "font_size_main_hq": 168,
            "font_size_sub_hq": 118,

            "default_save_mode": "new",
            "date_format": "YY.MM.DD",
            "time_format": "AM/PM"
        }
        self.load_settings()

        # --- タブコントロール（Notebook）の作成 ---
        self.notebook = ttk.Notebook(root)
        self.notebook.pack(fill="both", expand=True, padx=10, pady=10)

        # 1. メイン処理タブ
        self.tab_main = tk.Frame(self.notebook)
        self.notebook.add(self.tab_main, text=" メイン処理 ")

        # 2. 設定タブ
        self.tab_settings = tk.Frame(self.notebook)
        self.notebook.add(self.tab_settings, text=" 設定 ")

        # 各タブの中身を構築
        self.create_main_tab_widgets()
        self.create_settings_tab_widgets()

        # --- メニューバー（ツールバー）の作成 ---
        menubar = tk.Menu(root)

        menu_manage = tk.Menu(menubar, tearoff=0)
        menu_manage.add_command(label="写真を開く（追加）", command=self.select_images)
        menu_manage.add_separator()
        menu_manage.add_command(label="上書き保存モードに切替", command=lambda: self.save_mode.set("overwrite"))
        menu_manage.add_command(label="名前を付けて保存モードに切替", command=lambda: self.save_mode.set("new"))
        menu_manage.add_separator()
        menu_manage.add_command(label="終了", command=self.on_closing)
        menubar.add_cascade(label="管理", menu=menu_manage)

        menu_help = tk.Menu(menubar, tearoff=0)
        menu_help.add_command(label="ヘルプマニュアル", command=self.show_help)
        menu_help.add_command(label="バージョン情報", command=self.show_about)
        menubar.add_cascade(label="ヘルプ", menu=menu_help)

        root.config(menu=menubar)

        self.update_datetime()

    def load_settings(self):
        """Settings.dat から設定を読み込む"""
        if os.path.exists(self.settings_file):
            try:
                with open(self.settings_file, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                    self.settings.update(loaded)
            except Exception as e:
                print(f"設定の読み込みに失敗しました: {e}")

    def save_settings(self):
        """Settings.dat へ設定を保存する"""
        try:
            with open(self.settings_file, "w", encoding="utf-8") as f:
                json.dump(self.settings, f, ensure_ascii=False, indent=4)
            messagebox.showinfo("保存完了", "設定を Settings.dat に保存しました！")
        except Exception as e:
            messagebox.showerror("エラー", f"設定の保存に失敗しました:\n{e}")

    def get_current_scale(self):
        """現在のスタンプモードに応じた拡大率を取得"""
        if self.settings.get("high_quality_stamp", False):
            return self.settings.get("scale_hq", 15)
        else:
            return self.settings.get("scale_normal", 10)

    def create_main_tab_widgets(self):
        """「メイン処理」タブのUIを構築"""
        # 1. 写真リスト管理エリア
        frame_list = tk.LabelFrame(self.tab_main, text=" 選択した写真一覧 ", font=("Meiryo", 10))
        frame_list.pack(pady=5, padx=10, fill="x")

        self.btn_select = tk.Button(frame_list, text="① 写真を複数選択してインポート", command=self.select_images, font=("Meiryo", 10), width=35, height=1)
        self.btn_select.pack(pady=5)

        self.listbox = tk.Listbox(frame_list, height=4, font=("Meiryo", 9))
        self.listbox.pack(fill="x", padx=10, pady=5)

        # 2. 拡大率設定エリア（入力枠 ＋ スライダー）
        frame_scale = tk.LabelFrame(self.tab_main, text=" スタンプの拡大率（写真幅に対する割合） ", font=("Meiryo", 10))
        frame_scale.pack(pady=5, padx=10, fill="x")

        f_scale_input = tk.Frame(frame_scale)
        f_scale_input.pack(pady=3, padx=10, anchor="w")
        tk.Label(f_scale_input, text="拡大率(%):", font=("Meiryo", 9)).pack(side=tk.LEFT)

        self.scale_var = tk.IntVar(value=self.get_current_scale())
        
        self.spin_scale = tk.Spinbox(
            f_scale_input, 
            from_=1, 
            to=300, 
            textvariable=self.scale_var, 
            width=6, 
            font=("Meiryo", 10),
            command=self.on_spin_scale_changed
        )
        self.spin_scale.pack(side=tk.LEFT, padx=5)
        self.spin_scale.bind("<KeyRelease>", self.on_spin_scale_changed)

        self.slider = Scale(
            frame_scale, 
            from_=1, 
            to=300, 
            orient=tk.HORIZONTAL, 
            variable=self.scale_var, 
            font=("Meiryo", 9)
        )
        self.slider.pack(fill="x", padx=10, pady=3)

        # 3. 日時表示エリア
        frame_date = tk.Frame(self.tab_main)
        frame_date.pack(pady=2)
        tk.Label(frame_date, text="日付 (自動):", font=("Meiryo", 10), width=16, anchor="w").pack(side=tk.LEFT)
        self.entry_date = tk.Entry(frame_date, font=("Meiryo", 11), width=18, state="disabled", disabledbackground="#e0e0e0", disabledforeground="#000000")
        self.entry_date.pack(side=tk.LEFT, padx=5)

        frame_time = tk.Frame(self.tab_main)
        frame_time.pack(pady=2)
        tk.Label(frame_time, text="時間 (自動):", font=("Meiryo", 10), width=16, anchor="w").pack(side=tk.LEFT)
        self.entry_time = tk.Entry(frame_time, font=("Meiryo", 11), width=18, state="disabled", disabledbackground="#e0e0e0", disabledforeground="#000000")
        self.entry_time.pack(side=tk.LEFT, padx=5)

        # 4. 保存方法の選択
        self.save_mode = tk.StringVar(value=self.settings.get("default_save_mode", "new"))
        frame_mode = tk.LabelFrame(self.tab_main, text=" 保存方法の選択 ", font=("Meiryo", 10))
        frame_mode.pack(pady=5, padx=10, fill="x")

        tk.Radiobutton(frame_mode, text="名前を付けて保存（個別に保存先を指定）", variable=self.save_mode, value="new", font=("Meiryo", 9)).pack(anchor="w", padx=10, pady=2)
        tk.Radiobutton(frame_mode, text="上書き保存（元の写真をそのまま置き換える）", variable=self.save_mode, value="overwrite", font=("Meiryo", 9)).pack(anchor="w", padx=10, pady=2)

        # 5. 実行ボタン
        self.btn_execute = tk.Button(self.tab_main, text="② プレビューを開いて順番に配置する", command=self.start_batch_process, font=("Meiryo", 11, "bold"), bg="#ff5252", fg="white", width=35, height=2)
        self.btn_execute.pack(pady=8)

    def on_spin_scale_changed(self, event=None):
        try:
            val = int(self.scale_var.get())
            if val < 1:
                self.scale_var.set(1)
            elif val > 300:
                self.scale_var.set(300)
        except ValueError:
            pass

    def create_settings_tab_widgets(self):
        """「設定」タブのUIを構築（通常・高画質ごとの設定を分離）"""
        container = tk.Frame(self.tab_settings)
        container.pack(fill="both", expand=True, padx=5, pady=5)

        # 1. スタンプデータ・保存設定
        frame_stamp_cfg = tk.LabelFrame(container, text=" スタンプ・保存設定 ", font=("Meiryo", 9, "bold"))
        frame_stamp_cfg.pack(fill="x", padx=5, pady=3)

        self.hq_var = tk.BooleanVar(value=self.settings.get("high_quality_stamp", False))
        chk_hq = tk.Checkbutton(
            frame_stamp_cfg, 
            text="高画質スタンプデータを使用する (ok-high.png)", 
            variable=self.hq_var, 
            font=("Meiryo", 9),
            command=self.on_hq_toggled_ui
        )
        chk_hq.pack(anchor="w", padx=10, pady=2)

        self.backup_var = tk.BooleanVar(value=self.settings.get("auto_backup", True))
        tk.Checkbutton(frame_stamp_cfg, text="処理時に自動バックアップを作成する (./buckup/)", variable=self.backup_var, font=("Meiryo", 9)).pack(anchor="w", padx=10, pady=2)

        f_sm = tk.Frame(frame_stamp_cfg)
        f_sm.pack(fill="x", padx=10, pady=2)
        tk.Label(f_sm, text="初期保存方法:", font=("Meiryo", 9)).pack(side=tk.LEFT)
        self.def_save_var = tk.StringVar(value=self.settings.get("default_save_mode", "new"))
        tk.Radiobutton(f_sm, text="名前を付けて保存", variable=self.def_save_var, value="new", font=("Meiryo", 9)).pack(side=tk.LEFT, padx=5)
        tk.Radiobutton(f_sm, text="上書き保存", variable=self.def_save_var, value="overwrite", font=("Meiryo", 9)).pack(side=tk.LEFT, padx=5)

        # 2. 通常データ用設定 (拡大率・フォント)
        frame_normal_cfg = tk.LabelFrame(container, text=" 通常データ設定 (ok.png 用) ", font=("Meiryo", 9, "bold"))
        frame_normal_cfg.pack(fill="x", padx=5, pady=3)

        f_sc_n = tk.Frame(frame_normal_cfg)
        f_sc_n.pack(fill="x", padx=10, pady=2)
        tk.Label(f_sc_n, text="デフォルト拡大率(%):", font=("Meiryo", 9), width=18, anchor="w").pack(side=tk.LEFT)
        self.spin_scale_n = tk.Spinbox(f_sc_n, from_=1, to=300, width=5, font=("Meiryo", 9))
        self.spin_scale_n.delete(0, tk.END)
        self.spin_scale_n.insert(0, str(self.settings.get("scale_normal", 10)))
        self.spin_scale_n.pack(side=tk.LEFT, padx=5)

        f_fs1_n = tk.Frame(frame_normal_cfg)
        f_fs1_n.pack(fill="x", padx=10, pady=2)
        tk.Label(f_fs1_n, text="メインフォントサイズ:", font=("Meiryo", 9), width=18, anchor="w").pack(side=tk.LEFT)
        self.spin_fs_main_n = tk.Spinbox(f_fs1_n, from_=8, to=150, width=5, font=("Meiryo", 9))
        self.spin_fs_main_n.delete(0, tk.END)
        self.spin_fs_main_n.insert(0, str(self.settings.get("font_size_main_normal", 30)))
        self.spin_fs_main_n.pack(side=tk.LEFT, padx=5)

        f_fs2_n = tk.Frame(frame_normal_cfg)
        f_fs2_n.pack(fill="x", padx=10, pady=2)
        tk.Label(f_fs2_n, text="サブフォントサイズ(秒):", font=("Meiryo", 9), width=18, anchor="w").pack(side=tk.LEFT)
        self.spin_fs_sub_n = tk.Spinbox(f_fs2_n, from_=6, to=100, width=5, font=("Meiryo", 9))
        self.spin_fs_sub_n.delete(0, tk.END)
        self.spin_fs_sub_n.insert(0, str(self.settings.get("font_size_sub_normal", 26)))
        self.spin_fs_sub_n.pack(side=tk.LEFT, padx=5)

        # 3. 高画質データ用設定 (拡大率・フォント)
        frame_hq_cfg = tk.LabelFrame(container, text=" 高画質データ設定 (ok-high.png 用) ", font=("Meiryo", 9, "bold"))
        frame_hq_cfg.pack(fill="x", padx=5, pady=3)

        f_sc_h = tk.Frame(frame_hq_cfg)
        f_sc_h.pack(fill="x", padx=10, pady=2)
        tk.Label(f_sc_h, text="デフォルト拡大率(%):", font=("Meiryo", 9), width=18, anchor="w").pack(side=tk.LEFT)
        self.spin_scale_h = tk.Spinbox(f_sc_h, from_=1, to=300, width=5, font=("Meiryo", 9))
        self.spin_scale_h.delete(0, tk.END)
        self.spin_scale_h.insert(0, str(self.settings.get("scale_hq", 15)))
        self.spin_scale_h.pack(side=tk.LEFT, padx=5)

        f_fs1_h = tk.Frame(frame_hq_cfg)
        f_fs1_h.pack(fill="x", padx=10, pady=2)
        tk.Label(f_fs1_h, text="メインフォントサイズ:", font=("Meiryo", 9), width=18, anchor="w").pack(side=tk.LEFT)
        self.spin_fs_main_h = tk.Spinbox(f_fs1_h, from_=8, to=300, width=5, font=("Meiryo", 9))
        self.spin_fs_main_h.delete(0, tk.END)
        self.spin_fs_main_h.insert(0, str(self.settings.get("font_size_main_hq", 170)))
        self.spin_fs_main_h.pack(side=tk.LEFT, padx=5)

        f_fs2_h = tk.Frame(frame_hq_cfg)
        f_fs2_h.pack(fill="x", padx=10, pady=2)
        tk.Label(f_fs2_h, text="サブフォントサイズ(秒):", font=("Meiryo", 9), width=18, anchor="w").pack(side=tk.LEFT)
        self.spin_fs_sub_h = tk.Spinbox(f_fs2_h, from_=6, to=300, width=5, font=("Meiryo", 9))
        self.spin_fs_sub_h.delete(0, tk.END)
        self.spin_fs_sub_h.insert(0, str(self.settings.get("font_size_sub_hq", 120)))
        self.spin_fs_sub_h.pack(side=tk.LEFT, padx=5)

        # 4. 日付・時刻フォーマット設定
        frame_dt_cfg = tk.LabelFrame(container, text=" 日時表示形式設定 ", font=("Meiryo", 9, "bold"))
        frame_dt_cfg.pack(fill="x", padx=5, pady=3)

        f_df = tk.Frame(frame_dt_cfg)
        f_df.pack(fill="x", padx=10, pady=2)
        tk.Label(f_df, text="日付形式:", font=("Meiryo", 9), width=14, anchor="w").pack(side=tk.LEFT)
        self.date_format_var = tk.StringVar(value=self.settings.get("date_format", "YY.MM.DD"))
        date_options = ["YY.MM.DD", "MM.DD.YY", "DD.MM.YY", "YYYY.MM.DD", "MM.DD.YYYY", "DD.MM.YYYY", 
                        "YY/MM/DD", "MM/DD/YY", "DD/MM/YY", "YYYY/MM/DD", "MM/DD/YYYY", "DD/MM/YYYY"]
        cb_date = ttk.Combobox(f_df, textvariable=self.date_format_var, values=date_options, state="readonly", width=15, font=("Meiryo", 9))
        cb_date.pack(side=tk.LEFT, padx=5)

        f_tf = tk.Frame(frame_dt_cfg)
        f_tf.pack(fill="x", padx=10, pady=2)
        tk.Label(f_tf, text="時刻形式:", font=("Meiryo", 9), width=14, anchor="w").pack(side=tk.LEFT)
        self.time_format_var = tk.StringVar(value=self.settings.get("time_format", "AM/PM"))
        tk.Radiobutton(f_tf, text="AM/PM表示 (12h)", variable=self.time_format_var, value="AM/PM", font=("Meiryo", 9)).pack(side=tk.LEFT, padx=2)
        tk.Radiobutton(f_tf, text="23時表示 (24h)", variable=self.time_format_var, value="24H", font=("Meiryo", 9)).pack(side=tk.LEFT, padx=2)

        # 設定保存ボタン
        btn_save_settings = tk.Button(
            container, 
            text="設定を保存する", 
            command=self.apply_and_save_settings, 
            font=("Meiryo", 10, "bold"), 
            bg="#4caf50", 
            fg="white", 
            width=20, 
            height=1
        )
        btn_save_settings.pack(pady=5)

    def on_hq_toggled_ui(self):
        """設定タブ内で高画質切り替え時、メイン画面の拡大率を即座に連動させる"""
        self.settings["high_quality_stamp"] = self.hq_var.get()
        self.scale_var.set(self.get_current_scale())

    def apply_and_save_settings(self):
        """設定タブの内容を反映し、Settings.datに保存"""
        self.settings["high_quality_stamp"] = self.hq_var.get()
        self.settings["auto_backup"] = self.backup_var.get()
        self.settings["default_save_mode"] = self.def_save_var.get()
        self.settings["date_format"] = self.date_format_var.get()
        self.settings["time_format"] = self.time_format_var.get()
        
        try:
            self.settings["scale_normal"] = int(self.spin_scale_n.get())
            self.settings["font_size_main_normal"] = int(self.spin_fs_main_n.get())
            self.settings["font_size_sub_normal"] = int(self.spin_fs_sub_n.get())

            self.settings["scale_hq"] = int(self.spin_scale_h.get())
            self.settings["font_size_main_hq"] = int(self.spin_fs_main_h.get())
            self.settings["font_size_sub_hq"] = int(self.spin_fs_sub_h.get())
        except ValueError:
            pass

        self.save_mode.set(self.settings["default_save_mode"])
        self.scale_var.set(self.get_current_scale())
        self.save_settings()

    def get_formatted_datetime(self):
        now = datetime.now()
        d_fmt = self.settings.get("date_format", "YY.MM.DD")
        python_d_fmt = d_fmt.replace("YYYY", "%Y").replace("YY", "%y").replace("MM", "%m").replace("DD", "%d")
        date_str = now.strftime(python_d_fmt)

        t_fmt = self.settings.get("time_format", "AM/PM")
        if t_fmt == "24H":
            time_str = now.strftime("%H:%M:%S")
        else:
            time_str = now.strftime("AM %I:%M:%S" if now.hour < 12 else "PM %I:%M:%S")

        return date_str, time_str

    def update_datetime(self):
        date_str, time_str = self.get_formatted_datetime()
        
        self.entry_date.config(state="normal")
        self.entry_date.delete(0, tk.END)
        self.entry_date.insert(0, date_str)
        self.entry_date.config(state="disabled")
        
        self.entry_time.config(state="normal")
        self.entry_time.delete(0, tk.END)
        self.entry_time.insert(0, time_str)
        self.entry_time.config(state="disabled")

        self.root.after(1000, self.update_datetime)

    def select_images(self):
        file_paths = filedialog.askopenfilenames(
            title="合成元の写真を選択（複数選択可）",
            filetypes=[("画像ファイル", "*.jpg *.jpeg *.png *.bmp"), ("すべてのファイル", "*.*")]
        )
        if file_paths:
            self.target_image_paths = list(file_paths)
            self.listbox.delete(0, tk.END)
            for path in self.target_image_paths:
                self.listbox.insert(tk.END, os.path.basename(path))
            
            self.is_processed = False

    def create_stamp_image(self):
        is_hq = self.settings.get("high_quality_stamp", False)
        
        stamp_path = "ok.png"
        if is_hq:
            if os.path.exists("./images/ok-high.png"):
                stamp_path = "./images/ok-high.png"
            elif os.path.exists("ok-high.png"):
                stamp_path = "ok-high.png"
        
        if not os.path.exists(stamp_path):
            if os.path.exists("./images/ok.png"):
                stamp_path = "./images/ok.png"
            elif not os.path.exists(stamp_path):
                stamp_path = "ok.png"

        stamp = Image.open(stamp_path).convert("RGBA")

        txt_layer = Image.new("RGBA", stamp.size, (255, 255, 255, 0))
        draw = ImageDraw.Draw(txt_layer)

        font_path = "./images/font.ttf"
        if not os.path.exists(font_path):
            font_path = "font.ttf"

        # モードに応じたフォントサイズを取得
        if is_hq:
            fs_main = self.settings.get("font_size_main_hq", 170)
            fs_sub = self.settings.get("font_size_sub_hq", 120)
        else:
            fs_main = self.settings.get("font_size_main_normal", 30)
            fs_sub = self.settings.get("font_size_sub_normal", 26)

        try:
            font_main = ImageFont.truetype(font_path, fs_main)
            font_sub = ImageFont.truetype(font_path, fs_sub)
        except IOError:
            font_main = ImageFont.load_default()
            font_sub = ImageFont.load_default()

        stamp_color = (210, 40, 40, 240)
        date_str, time_str = self.get_formatted_datetime()

        if len(time_str) >= 3 and time_str[-3] == ":":
            main_time = time_str[:-3]
            sec_part = time_str[-3:]
        else:
            main_time = time_str
            sec_part = ""

        bbox_d = draw.textbbox((0, 0), date_str, font=font_main)
        bbox_t = draw.textbbox((0, 0), main_time, font=font_main)
        bbox_s = draw.textbbox((0, 0), sec_part, font=font_sub)

        w_date = bbox_d[2] - bbox_d[0]
        h_date = bbox_d[3] - bbox_d[1]
        w_time_main = bbox_t[2] - bbox_t[0]
        w_time_sec = bbox_s[2] - bbox_s[0]
        h_time = max(bbox_t[3] - bbox_t[1], bbox_s[3] - bbox_s[1])

        total_w = max(w_date, w_time_main + w_time_sec)
        total_h = h_date + h_time + 4

        start_x = (stamp.width - total_w) // 2
        start_y = (stamp.height - total_h) // 2

        x_date = start_x + (total_w - w_date) // 2
        draw.text((x_date, start_y), date_str, fill=stamp_color, font=font_main)

        y_time = start_y + h_date + 4
        total_time_w = w_time_main + w_time_sec
        x_time_start = start_x + (total_w - total_time_w) // 2
        draw.text((x_time_start, y_time), main_time, fill=stamp_color, font=font_main)
        draw.text((x_time_start + w_time_main, y_time + 2), sec_part, fill=stamp_color, font=font_sub)

        return Image.alpha_composite(stamp, txt_layer)

    def start_batch_process(self):
        if not self.target_image_paths:
            messagebox.showerror("エラー", "先に「合成元の写真」を1枚以上選択してください。")
            return
        
        self.process_image_index(0)

    def process_image_index(self, index):
        if index >= len(self.target_image_paths):
            self.is_processed = True
            messagebox.showinfo("完了", "すべての写真へのスタンプ合成とバックアップ保存が完了しました！")
            return

        image_path = self.target_image_paths[index]
        self.open_preview_window(image_path, index)

    def open_preview_window(self, image_path, index):
        preview_win = Toplevel(self.root)
        preview_win.title(f"[{index+1}/{len(self.target_image_paths)}] 写真をクリックしてスタンプ位置を決定")

        try:
            pil_img = Image.open(image_path)
            orig_w, orig_h = pil_img.size

            max_w, max_h = 800, 600
            scale = min(max_w / orig_w, max_h / orig_h, 1.0)
            
            disp_w = int(orig_w * scale)
            disp_h = int(orig_h * scale)

            disp_img = pil_img.resize((disp_w, disp_h), Image.Resampling.LANCZOS)
            base_tk_img = ImageTk.PhotoImage(disp_img)

            filename = os.path.basename(image_path)
            lbl_instruct = tk.Label(preview_win, text=f"({index+1}/{len(self.target_image_paths)}) {filename} - クリックしてスタンプを配置", font=("Meiryo", 10), fg="red")
            lbl_instruct.pack(pady=5)

            canvas = tk.Canvas(preview_win, width=disp_w, height=disp_h, cursor="cross")
            canvas.pack()
            canvas.create_image(0, 0, anchor=tk.NW, image=base_tk_img)

            raw_stamp = self.create_stamp_image()
            scale_percent = self.scale_var.get()
            target_width_orig = int(orig_w * (scale_percent / 100.0))
            aspect_ratio = raw_stamp.height / raw_stamp.width
            target_height_orig = int(target_width_orig * aspect_ratio)

            disp_stamp_w = int(target_width_orig * scale)
            disp_stamp_h = int(target_height_orig * scale)

            resized_stamp = raw_stamp.resize((max(1, disp_stamp_w), max(1, disp_stamp_h)), Image.Resampling.LANCZOS)
            stamp_tk_img = ImageTk.PhotoImage(resized_stamp)

            stamp_item = canvas.create_image(-100, -100, anchor=tk.CENTER, image=stamp_tk_img)

            def on_mouse_move(event):
                canvas.coords(stamp_item, event.x, event.y)

            canvas.bind("<Motion>", on_mouse_move)

            def on_canvas_click(event):
                orig_x = int(event.x / scale)
                orig_y = int(event.y / scale)
                preview_win.destroy()
                
                self.save_single_image(image_path, orig_x, orig_y)
                self.process_image_index(index + 1)

            canvas.bind("<Button-1>", on_canvas_click)

            preview_win.base_tk_img = base_tk_img
            preview_win.stamp_tk_img = stamp_tk_img

        except Exception as e:
            messagebox.showerror("エラー", f"プレビューの表示に失敗しました:\n{e}")

    def save_single_image(self, image_path, click_x, click_y):
        date_str, time_str = self.get_formatted_datetime()

        try:
            if self.save_mode.get() == "overwrite":
                output_path = image_path
            else:
                base_dir = os.path.dirname(image_path)
                base_name, ext = os.path.splitext(os.path.basename(image_path))
                output_path = filedialog.asksaveasfilename(
                    initialdir=base_dir,
                    initialfile=f"{base_name}_stamped{ext}",
                    defaultextension=ext,
                    filetypes=[("画像ファイル", f"*{ext}"), ("すべてのファイル", "*.*")]
                )
                if not output_path:
                    return

            self.apply_stamp_to_image(image_path, output_path, date_str, time_str, click_x, click_y)

            if self.settings.get("auto_backup", True):
                backup_dir = "./buckup"
                if not os.path.exists(backup_dir):
                    os.makedirs(backup_dir)

                counter = 1
                while True:
                    backup_filename = f"Copy{counter}.png"
                    backup_path = os.path.join(backup_dir, backup_filename)
                    if not os.path.exists(backup_path):
                        break
                    counter += 1

                base_img = Image.open(output_path).convert("RGB")
                base_img.save(backup_path, "PNG")

        except Exception as e:
            messagebox.showerror("エラー", f"保存中にエラーが発生しました:\n{e}")

    def apply_stamp_to_image(self, bg_path, out_path, date_str, time_str, click_x, click_y):
        base = Image.open(bg_path).convert("RGBA")
        stamped_stamp = self.create_stamp_image()

        scale_percent = self.scale_var.get()
        target_width = int(base.width * (scale_percent / 100.0))
        aspect_ratio = stamped_stamp.height / stamped_stamp.width
        target_height = int(target_width * aspect_ratio)

        # 高画質時は縮小時の劣化を防ぐため LANCZOS で高品質リサイズ
        stamped_stamp = stamped_stamp.resize((max(1, target_width), max(1, target_height)), Image.Resampling.LANCZOS)

        paste_x = click_x - (target_width // 2)
        paste_y = click_y - (target_height // 2)

        base.paste(stamped_stamp, (paste_x, paste_y), stamped_stamp)

        # 圧縮せずそのまま綺麗に保存（JPGの場合は最高品質95、PNGはロスレス）
        if out_path.lower().endswith(('.jpg', '.jpeg')):
            base.convert("RGB").save(out_path, quality=95, subsampling=0)
        else:
            base.save(out_path, compress_level=0)

    def on_closing(self):
        if not self.is_processed and len(self.target_image_paths) > 0:
            if not messagebox.askyesno("警告：未保存のデータがあります", "まだスタンプ処理が完了していない写真があります。\nこのまま終了してもよろしいですか？"):
                return
        else:
            if not messagebox.askyesno("確認", "アプリケーションを終了しますか？"):
                return

        self.root.destroy()

    def show_help(self):
        help_text = (
            "【 変更点 】\n\n"
            "■ 設定タブの分離について\n"
            "   - 通常データ (ok.png) と高画質データ (ok-high.png) で、拡大率・メインフォント・秒数フォントをそれぞれ独立して設定・保存できるようになりました。\n"
            "   - 画像は圧縮を行わず、高画質なまま合成・保存されます。\n"
            "【 操作マニュアル 】\n\n"
            "■ 1. メイン処理タブ\n"
            "   - 写真の選択、スタンプ大きさ調整、保存方法を選択して処理を実行します。\n\n"
            "■ 2. 設定タブ\n"
            "   - デフォルトの拡大率、保存方法、日付・時刻のフォーマット、フォントサイズを細かく設定できます。\n"
            "   - 変更後は「設定を保存する」ボタンを押すと Settings.dat に保存されます。\n\n"
            "■ 3. 終了時の確認\n"
            "   - 未処理データがある場合は警告メッセージが表示されます。"
        )
        messagebox.showinfo("ヘルプマニュアル", help_text)

    def show_about(self):
        about_win = Toplevel(self.root)
        about_win.title("バージョン情報")
        about_win.geometry("370x240")
        about_win.resizable(False, False)

        try:
            img_icon = Image.open("./images/software-icon.png").resize((64, 64), Image.Resampling.LANCZOS)
            photo_icon = ImageTk.PhotoImage(img_icon)
            lbl_img = tk.Label(about_win, image=photo_icon)
            lbl_img.image = photo_icon
            lbl_img.pack(pady=15)
        except Exception:
            tk.Label(about_win, text="[Icon]", font=("Meiryo", 12)).pack(pady=15)

        tk.Label(about_win, text="デジタルスタンプ配置ソフト TSSTAMP", font=("Meiryo", 11, "bold")).pack()
        tk.Label(about_win, text="Version 1.0a (2026.08.24)", font=("Meiryo", 9), fg="gray").pack(pady=5)
        tk.Label(about_win, text="Copyright (c) 2026 Home Made Tools Project All Rights Reserved.", font=("Meiryo", 8)).pack(pady=5)

        tk.Button(about_win, text="閉じる", command=about_win.destroy, width=10).pack(pady=5)

if __name__ == "__main__":
    root = tk.Tk()
    app = StampApp(root)
    root.mainloop()